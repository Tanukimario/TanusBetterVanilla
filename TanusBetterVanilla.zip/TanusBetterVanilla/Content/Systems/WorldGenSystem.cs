using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.WorldBuilding;
using Terraria.IO;
using Microsoft.Xna.Framework;
using TanusBetterVanilla.Content.Tiles.Blocks;

namespace TanusBetterVanilla.Content.Systems
{
    public class WorldGenSystem : ModSystem
    {
        public override void PostWorldGen()
        {
            // Weltgröße bestimmen
            int worldWidth = Main.maxTilesX;
            int worldHeight = Main.maxTilesY;
            int oceanWidth = (int)(worldWidth * 0.05); // ca. 5% vom Kartenrand

            for (int x = 0; x < worldWidth; x++)
            {
                // Prüfen ob in linker oder rechter Ozeanzone
                if (x < oceanWidth || x > worldWidth - oceanWidth)
                {
                    for (int y = 50; y < worldHeight - 100; y++) // Nahe der Oberfläche bis untere Weltgrenze
                    {
                        Tile tile = Framing.GetTileSafely(x, y);

                        // Nur wenn der aktuelle Tile Sand ist
                        if (tile.HasTile && tile.TileType == TileID.Sand)
                        {
                            if (Main.rand.NextBool(700)) // Chance je Tile (je kleiner desto häufiger)
                            {
                                // Erzeuge eine kleine Erzader aus deinem Custom-Block
                                WorldGen.OreRunner(x, y, Main.rand.Next(2, 5), Main.rand.Next(2, 4), (ushort)ModContent.TileType<ShimmeringSandTile>());
                            }
                        }
                    }
                }
            }
        }
    }
}