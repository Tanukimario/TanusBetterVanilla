using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.DataStructures;
using Microsoft.Xna.Framework;
using TanusBetterVanilla.Content.Items.Weapons.Magic;
using TanusBetterVanilla.Content.Items.Weapons.Summoner;
using TanusBetterVanilla.Content.Items.Consumable;
using TanusBetterVanilla.Content.Items.Accessories;
using TanusBetterVanilla.Content.Projectiles;
using System;
using System.Collections.Generic;

namespace TanusBetterVanilla.Content.Systems
{
    public class GlobalDropNPC : GlobalNPC
    {
        public override void OnKill(NPC npc)
        {
            if (npc.type == 439 && Main.rand.NextFloat() < 0.33f) //Cultist
            {
                Item.NewItem(npc.GetSource_Loot(), npc.getRect(), ModContent.ItemType<CultistsSpell>());
            }

            if (npc.type == 418 | npc.type == 518 | npc.type == 415 | npc.type == 416 | npc.type == 419 | npc.type == 417 && Main.rand.NextFloat() < 0.15f) //Solar Enemies
            {
                Item.NewItem(npc.GetSource_Loot(), npc.getRect(), ItemID.FragmentSolar);
            }

            if (npc.type == 427 | npc.type == 426 | npc.type == 425 | npc.type == 429 && Main.rand.NextFloat() < 0.15f) //Vortex Enemies
            {
                Item.NewItem(npc.GetSource_Loot(), npc.getRect(), ItemID.FragmentVortex);
            }

            if (npc.type == 421 | npc.type == 423 | npc.type == 420 | npc.type == 424 && Main.rand.NextFloat() < 0.15f) //Nebula Enemies
            {
                Item.NewItem(npc.GetSource_Loot(), npc.getRect(), ItemID.FragmentNebula);
            }

            if (npc.type == 407 | npc.type == 405 | npc.type == 411 | npc.type == 409 && Main.rand.NextFloat() < 0.15f) //Stardust Enemies
            {
                Item.NewItem(npc.GetSource_Loot(), npc.getRect(), ItemID.FragmentStardust);
            }

            if (npc.type == 44 && Main.rand.NextFloat() < 1f) //Undead Miner 
            {
                Item.NewItem(npc.GetSource_Loot(), npc.getRect(), ModContent.ItemType<OreBag>());
            }

            if (npc.type == 20 && Main.rand.NextFloat() < 1f) //Dryad
            {
                Item.NewItem(npc.GetSource_Loot(), npc.getRect(), 3093);
            }

            if (npc.type == 369 && Main.rand.NextFloat() < 1f) //Angler
            {
                Item.NewItem(npc.GetSource_Loot(), npc.getRect(), 4345);
            }

            if (npc.type == 125 | npc.type == 126 | npc.type == 134 | npc.type == 127 && Main.rand.NextFloat() < 0.05f) //Mech Bosses
            {
                Item.NewItem(npc.GetSource_Loot(), npc.getRect(), ModContent.ItemType<VitalMechParts>());
            }

            if (npc.type == 125 | npc.type == 126 | npc.type == 134 | npc.type == 127 && Main.rand.NextFloat() < 0.05f) //Mech Bosses
            {
                Item.NewItem(npc.GetSource_Loot(), npc.getRect(), ModContent.ItemType<OffensiveMechParts>());
            }

            if (npc.type == 125 | npc.type == 126 | npc.type == 134 | npc.type == 127 && Main.rand.NextFloat() < 0.05f) //Mech Bosses
            {
                Item.NewItem(npc.GetSource_Loot(), npc.getRect(), ModContent.ItemType<MechanicalEngineParts>());
            }

            if (npc.type == 471 && Main.rand.NextFloat() < 0.167f) //Goblin Warlock
            {
                Item.NewItem(npc.GetSource_Loot(), npc.getRect(), ModContent.ItemType<ShadowflamePortalStaff>());
            }           
        }
    }
}