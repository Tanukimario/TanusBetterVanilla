using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.ObjectData;
using System;
using System.Collections.Generic;

namespace TanusBetterVanilla.Content.Tiles.Blocks
{
    public class ShimmeringSandTile : ModTile
    {
        public override void SetStaticDefaults()
        {
            Main.tileSolid[Type] = true;           // Solides Blocktile
            Main.tileBlockLight[Type] = true;      // Blockiert Licht
            Main.tileMergeDirt[Type] = true; // verhindert Verbindung mit Erde
            Main.tileBlendAll[this.Type] = true; // keine Texturüberblendung
            Main.tileLighted[Type] = true;
            Main.tileSpelunker[Type] = true;
            Main.tileOreFinderPriority[Type] = 510;

            // Mapanzeige
            AddMapEntry(new Color(200, 200, 200), CreateMapEntryName());

            // Tile-Verhalten (kein Verbinden)
            Main.tileFrameImportant[Type] = false;
            Main.tileMerge[Type][TileID.Sand] = true;
            Main.tileMerge[TileID.Sand][Type] = true;

            // Eigenschaften
            HitSound = SoundID.Tink;
            MineResist = 1f;     // Wie widerstandsfähig beim Abbauen
            MinPick = 65;         // Welches Werkzeug nötig ist

            RegisterItemDrop(ModContent.ItemType<Items.Tiles.ShimmeringSand>());
        }
    }
}