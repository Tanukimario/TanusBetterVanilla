using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.DataStructures;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using Terraria.ObjectData;

namespace TanusBetterVanilla.Content.Tiles.Furniture
{
    public class BorbPlush : ModTile
    {
        public override void SetStaticDefaults()
        {
            Main.tileFrameImportant[Type] = true;

            TileObjectData.newTile.CopyFrom(TileObjectData.Style2x2);
            TileObjectData.newTile.CoordinateHeights = new[] { 16, 16 }; // richtig: 2x16px = 32px hoch
            TileObjectData.newTile.Origin = new Point16(0, 1); // wichtig für Platzierung
            TileObjectData.addTile(Type);

            AddMapEntry(new Color(200, 200, 200), CreateMapEntryName());
            DustType = DustID.WoodFurniture;
            AdjTiles = new int[] { TileID.Chairs }; // optional
        }
    }
}