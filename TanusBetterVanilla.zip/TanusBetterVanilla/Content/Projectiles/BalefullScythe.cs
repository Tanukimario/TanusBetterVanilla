using Terraria;
using Terraria.ModLoader;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Terraria.DataStructures;
using Terraria.Audio;
using System;

namespace TanusBetterVanilla.Content.Projectiles
{
    public class BalefullScythe : ModProjectile
    {
        public override void SetDefaults()
        {
            Projectile.DamageType = DamageClass.Melee; // Damage class projectile uses
            Projectile.scale = 1f; // Projectile scale multiplier
            Projectile.penetrate = 5; // How many hits projectile have to make before it dies. 3 means projectile will die on 3rd enemy. Setting this to 0 will make projectile die instantly
            Projectile.aiStyle = 0; // AI style of a projectile. 0 is default bullet AI
            Projectile.width = Projectile.height = 10; // Hitbox of projectile in pixels
            Projectile.friendly = true; // Can hit enemies?
            Projectile.hostile = false; // Can hit player?
            Projectile.timeLeft = 270; // Time in ticks before projectile dies
            Projectile.light = 0.3f; // How much light projectile provides
            Projectile.ignoreWater = true; // Does the projectile ignore water (doesn't slow down in it)
            Projectile.tileCollide = false; // Does the projectile collide with tiles, like blocks?
            Projectile.alpha = 25; // Completely transparent
        }
        public override string Texture => "TanusBetterVanilla/Content/Projectiles/BalefullScythe"; // We will use no texture

        public override void AI() // This hook updates every tick
        {
            Projectile.rotation += 0.25f;
            Projectile.velocity = Projectile.velocity * 0.98f;
            Projectile.alpha += 2;

            if (Projectile.alpha > 255)
            {
                Projectile.alpha = 255;
                Projectile.Kill();
            }
            if (Projectile.velocity.Length() < 0.1f)
            {
                Projectile.velocity = Vector2.Zero;
            }

            if (Main.netMode != NetmodeID.Server)
            {
                Vector2 center = Projectile.Center;
                Vector2 spawnArea = new Vector2(Projectile.width + 20, Projectile.height + 20); // z. B. 20px größer
                Vector2 randomOffset = new Vector2(Main.rand.NextFloat(-spawnArea.X / 2, spawnArea.X / 2), Main.rand.NextFloat(-spawnArea.Y / 2, spawnArea.Y / 2));
                Vector2 spawnPosition = Projectile.Center + randomOffset;
                
                Dust dust1 = Dust.NewDustDirect(center - new Vector2(4, 4), 8, 8, DustID.OrangeTorch);
                dust1.velocity = new Vector2(Main.rand.NextFloat(-2f, 2f), Main.rand.NextFloat(-2f, 2f));
                dust1.scale = 1.2f;
                dust1.noGravity = true;

                Dust dust2 = Dust.NewDustDirect(center - new Vector2(4, 4), 8, 8, DustID.GoldFlame);
                dust2.velocity = new Vector2(Main.rand.NextFloat(-2f, 2f), Main.rand.NextFloat(-2f, 2f));
                dust2.scale = 1.2f;
                dust2.noGravity = true;
            }
        }
    }
}