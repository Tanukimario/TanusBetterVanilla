using Terraria;
using Terraria.ModLoader;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Terraria.DataStructures;
using Terraria.Audio;
using System;

namespace TanusBetterVanilla.Content.Projectiles
{
    public class CultistStar : ModProjectile
    {
        public override void SetDefaults()
        {
            Projectile.DamageType = DamageClass.Magic; // Damage class projectile uses
            Projectile.scale = 2f; // Projectile scale multiplier
            Projectile.penetrate = 1; // How many hits projectile have to make before it dies. 3 means projectile will die on 3rd enemy. Setting this to 0 will make projectile die instantly
            Projectile.aiStyle = 0; // AI style of a projectile. 0 is default bullet AI
            Projectile.width = Projectile.height = 10; // Hitbox of projectile in pixels
            Projectile.friendly = true; // Can hit enemies?
            Projectile.hostile = false; // Can hit player?
            Projectile.timeLeft = 300; // Time in ticks before projectile dies
            Projectile.light = 0.3f; // How much light projectile provides
            Projectile.ignoreWater = true; // Does the projectile ignore water (doesn't slow down in it)
            Projectile.tileCollide = true; // Does the projectile collide with tiles, like blocks?
            Projectile.alpha = 25; // Completely transparent
        }
        public override string Texture => "TanusBetterVanilla/Content/Projectiles/CultistStar"; // We will use no texture

        public override void AI() // This hook updates every tick
        {
            Projectile.rotation += 0.1f;
            if (Main.netMode != NetmodeID.Server) // Do not spawn dust on server!
            {
                Dust dust = Dust.NewDustPerfect(
            Projectile.Center,
            DustID.IceTorch,           // Use DustID.Torch for a fiery effect
            Vector2.Zero,
            100,
            Color.LightBlue,        // Optional: fiery color
            3f                    // Larger scale for a ball-like effect
            );
                dust.noGravity = true;
                dust.fadeIn = 0.5f;
            }
        }

        public override void OnKill(int timeLeft)
        {
            int numDust = 30;
            for (int i = 0; i < numDust; i++)
            {
                // Random direction and speed
                Vector2 velocity = Main.rand.NextVector2Circular(4f, 4f);
                Dust dust = Dust.NewDustPerfect(
                    Projectile.Center,
                    DustID.IceTorch,
                    velocity,
                    150,
                    Color.LightBlue,
                    2.5f
                );
                dust.noGravity = true;
                dust.fadeIn = 1f;
            }
        }

        public override void OnSpawn(Terraria.DataStructures.IEntitySource source)
        {
            int numDust = 20;
            for (int i = 0; i < numDust; i++) // Loop through code below numDust times
            {
                Vector2 velocity = Vector2.One.RotatedBy(MathHelper.ToRadians(360 / numDust * i)); // Circular velocity
                Dust.NewDustPerfect(Projectile.Center, DustID.FlameBurst, velocity).noGravity = true; // Creating dust
            }
        }

        public override void OnHitNPC(NPC target, NPC.HitInfo hit, int damageDone)
        {
            int confusedID = 46;
            target.buffImmune[confusedID] = false;  // Immunität aufheben
            target.AddBuff(confusedID, 300);
        }
    }
}

