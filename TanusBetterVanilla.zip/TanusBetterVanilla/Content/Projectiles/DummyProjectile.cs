using Terraria;
using Terraria.ModLoader;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Terraria.DataStructures;
using Terraria.Audio;

namespace TanusBetterVanilla.Content.Projectiles
{
    public class DummyProjectile : ModProjectile
    {
        public override void SetDefaults()
        {
            Projectile.DamageType = DamageClass.Melee;
            Projectile.scale = 0f;
            Projectile.penetrate = 0;
            Projectile.aiStyle = 0;
            Projectile.width = Projectile.height = 0;
            Projectile.friendly = false;
            Projectile.hostile = false;
            Projectile.timeLeft = 0;
            Projectile.light = 0.0f;
            Projectile.ignoreWater = true;
            Projectile.tileCollide = true;
            Projectile.alpha = 255;
        }
        public override string Texture => "Terraria/Images/Projectile_0"; // We will use no texture
    }
}