using Terraria;
using Terraria.ModLoader;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Terraria.DataStructures;
using Terraria.Audio;
using System;

namespace TanusBetterVanilla.Content.Projectiles
{
    public class NebulaShard : ModProjectile
    {
        public override void SetDefaults()
        {
            Projectile.DamageType = DamageClass.Magic; // Damage class projectile uses
            Projectile.scale = 2f; // Projectile scale multiplier
            Projectile.penetrate = 2; // How many hits projectile have to make before it dies. 3 means projectile will die on 3rd enemy. Setting this to 0 will make projectile die instantly
            Projectile.aiStyle = -1; // AI style of a projectile. 0 is default bullet AI
            Projectile.width = Projectile.height = 10; // Hitbox of projectile in pixels
            Projectile.friendly = true; // Can hit enemies?
            Projectile.hostile = false; // Can hit player?
            Projectile.timeLeft = 150; // Time in ticks before projectile dies
            Projectile.light = 0.3f; // How much light projectile provides
            Projectile.ignoreWater = true; // Does the projectile ignore water (doesn't slow down in it)
            Projectile.tileCollide = false; // Does the projectile collide with tiles, like blocks?
            Projectile.alpha = 25; // Completely transparent
        }
        public override string Texture => "Terraria/Images/Projectile_0"; // We will use no texture

        public override void AI() // This hook updates every tick
        {
            if (Main.netMode != NetmodeID.Server) // Do not spawn dust on server!
            {
                Dust dust1 = Dust.NewDustPerfect(
                    Position: Projectile.Center,
                    Type: DustID.PinkCrystalShard,
                    Velocity: Vector2.Zero,
                    Alpha: 100,
                    Scale: 1.2f
                );
                dust1.noGravity = true; // Dust don't have gravity
                dust1.fadeIn = -1f;

                Dust dust2 = Dust.NewDustPerfect(
                    Position: Projectile.Center,
                    Type: DustID.PurpleCrystalShard,
                    Velocity: Vector2.Zero,
                    Alpha: 100,
                    Scale: 1.2f
                );
                dust2.noGravity = true; // Dust don't have gravity
                dust2.fadeIn = -1f;
            }

            float desiredSpeed = Projectile.velocity.Length(); // Die gewünschte konstante Geschwindigkeit
            float maxTurn = 0.04f; // Wie stark darf sich das Projektil pro Frame drehen?

            NPC target = null;
            float maxDetectRadius = 200f;

            // Zielsuche: Finde nächsten feindlichen NPC
            for (int i = 0; i < Main.maxNPCs; i++)
            {
                NPC npc = Main.npc[i];
                if (npc.CanBeChasedBy(this))
                {
                    float distance = Vector2.Distance(Projectile.Center, npc.Center);
                    if (distance < maxDetectRadius && (target == null || distance < Vector2.Distance(Projectile.Center, target.Center)))
                        target = npc;
                }
            }

            if (target != null)
            {
                Vector2 toTarget = target.Center - Projectile.Center;
                toTarget.Normalize();

                // Aktuelle Richtung des Projektils
                Vector2 currentDir = Projectile.velocity;
                currentDir.Normalize();

                // Errechne die neue, leicht gedrehte Richtung
                float currentAngle = (float)Math.Atan2(currentDir.Y, currentDir.X);
                float targetAngle = (float)Math.Atan2(toTarget.Y, toTarget.X);

                // Winkelunterschied clamped auf Max-Drehwinkel pro Frame
                float newAngle = Utils.AngleLerp(currentAngle, targetAngle, maxTurn);

                // Neue Velocity erzeugen, aber Geschwindigkeit beibehalten!
                Vector2 newVelocity = new Vector2((float)Math.Cos(newAngle), (float)Math.Sin(newAngle)) * desiredSpeed;
                Projectile.velocity = newVelocity;
            }
        }

        public override void OnKill(int timeLeft)
        {
            if (Main.netMode != NetmodeID.Server) // Do not spawn dust on server!
            {
                Dust dust1 = Dust.NewDustPerfect(
                    Position: Projectile.Center,
                    Type: DustID.PinkCrystalShard,
                    Velocity: Vector2.Zero,
                    Alpha: 100,
                    Scale: 1.2f
                );
                dust1.noGravity = true; // Dust don't have gravity
                dust1.fadeIn = -1f;

                Dust dust2 = Dust.NewDustPerfect(
                    Position: Projectile.Center,
                    Type: DustID.PurpleCrystalShard,
                    Velocity: Vector2.Zero,
                    Alpha: 100,
                    Scale: 1.2f
                );
                dust2.noGravity = true; // Dust don't have gravity
                dust2.fadeIn = -1f;
            }
        }
    }
}