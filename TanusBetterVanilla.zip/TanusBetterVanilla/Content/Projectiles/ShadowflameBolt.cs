using Terraria;
using Terraria.ModLoader;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Terraria.DataStructures;
using Terraria.Audio;
using System;

namespace TanusBetterVanilla.Content.Projectiles
{
    public class ShadowflameBolt : ModProjectile
    {
        public override void SetDefaults()
        {
            Projectile.DamageType = DamageClass.Magic; // Damage class projectile uses
            Projectile.scale = 1f; // Projectile scale multiplier
            Projectile.penetrate = 1; // How many hits projectile have to make before it dies. 3 means projectile will die on 3rd enemy. Setting this to 0 will make projectile die instantly
            Projectile.aiStyle = 0; // AI style of a projectile. 0 is default bullet AI
            Projectile.width = Projectile.height = 10; // Hitbox of projectile in pixels
            Projectile.friendly = true; // Can hit enemies?
            Projectile.hostile = false; // Can hit player?
            Projectile.timeLeft = 270; // Time in ticks before projectile dies
            Projectile.light = 0.3f; // How much light projectile provides
            Projectile.ignoreWater = true; // Does the projectile ignore water (doesn't slow down in it)
            Projectile.tileCollide = true; // Does the projectile collide with tiles, like blocks?
            Projectile.alpha = 25; // Completely transparent
        }
        public override string Texture => "TanusBetterVanilla/Content/Projectiles/ShadowflameBolt"; // We will use no texture

        public override void AI() // This hook updates every tick
        {
            Projectile.rotation += 0.1f;
            if (Main.netMode != NetmodeID.Server) // Do not spawn dust on server!
            {
                Dust dust = Dust.NewDustDirect(Projectile.position, Projectile.width, Projectile.height, DustID.Shadowflame);
                dust.velocity *= 0.3f;
                dust.scale = 1.2f;
                dust.noGravity = true;
            }

            if (Main.netMode != NetmodeID.Server) // Do not spawn dust on server!
            {
                Dust dust = Dust.NewDustDirect(Projectile.position, Projectile.width, Projectile.height, DustID.PurpleTorch);
                dust.velocity *= 0.3f;
                dust.scale = 1.2f;
                dust.noGravity = true;
            }

            float desiredSpeed = Projectile.velocity.Length(); // Die gewünschte konstante Geschwindigkeit
            float maxTurn = 0.04f; // Wie stark darf sich das Projektil pro Frame drehen?

            NPC target = null;
            float maxDetectRadius = 200f;

            // Zielsuche: Finde nächsten feindlichen NPC
            for (int i = 0; i < Main.maxNPCs; i++)
            {
                NPC npc = Main.npc[i];
                if (npc.CanBeChasedBy(this))
                {
                    float distance = Vector2.Distance(Projectile.Center, npc.Center);
                    if (distance < maxDetectRadius && (target == null || distance < Vector2.Distance(Projectile.Center, target.Center)))
                        target = npc;
                }
            }

            if (target != null)
            {
                Vector2 toTarget = target.Center - Projectile.Center;
                toTarget.Normalize();

                // Aktuelle Richtung des Projektils
                Vector2 currentDir = Projectile.velocity;
                currentDir.Normalize();

                // Errechne die neue, leicht gedrehte Richtung
                float currentAngle = (float)Math.Atan2(currentDir.Y, currentDir.X);
                float targetAngle = (float)Math.Atan2(toTarget.Y, toTarget.X);

                // Winkelunterschied clamped auf Max-Drehwinkel pro Frame
                float newAngle = Utils.AngleLerp(currentAngle, targetAngle, maxTurn);

                // Neue Velocity erzeugen, aber Geschwindigkeit beibehalten!
                Vector2 newVelocity = new Vector2((float)Math.Cos(newAngle), (float)Math.Sin(newAngle)) * desiredSpeed;
                Projectile.velocity = newVelocity;
            }
        }

        public override void OnKill(int timeLeft)
        {
            // Play explosion sound
            SoundEngine.PlaySound(SoundID.Item14, Projectile.Center);

            int numDust = 30;
            for (int i = 0; i < numDust; i++)
            {
                // Random direction and speed
                Vector2 velocity = Main.rand.NextVector2Circular(4f, 4f);
                Dust dust = Dust.NewDustDirect(Projectile.position, Projectile.width, Projectile.height, DustID.Shadowflame);
                dust.velocity *= 0.3f;
                dust.scale = 1.2f;
                dust.noGravity = true;
                dust.noGravity = true;
                dust.fadeIn = 1f;
            }

            int explosionRadius = 60;
            int explosionDamage = (int)(Projectile.damage * 1.5);
            for (int k = 0; k < Main.maxNPCs; k++)
            {
                NPC npc = Main.npc[k];
                if (npc.active && !npc.friendly && npc.Distance(Projectile.Center) < explosionRadius)
                {
                    int direction = npc.Center.X > Projectile.Center.X ? 1 : -1;
                    NPC.HitInfo hitInfo = new NPC.HitInfo()
                    {
                        Damage = explosionDamage,
                        Knockback = 0f,
                        HitDirection = direction,
                        Crit = false
                    };
                    npc.StrikeNPC(hitInfo);
                }
            }
        }
        public override void OnHitNPC(NPC target, NPC.HitInfo hit, int damageDone)
        {
            target.AddBuff(153, 300);
        }
    }
}