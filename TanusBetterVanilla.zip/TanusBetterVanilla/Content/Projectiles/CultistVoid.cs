using Terraria;
using Terraria.ModLoader;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Terraria.DataStructures;
using Terraria.Audio;
using System;

namespace TanusBetterVanilla.Content.Projectiles
{
    public class CultistVoid : ModProjectile
    {
        public override void SetDefaults()
        {
            Projectile.DamageType = DamageClass.Magic; // Damage class projectile uses
            Projectile.scale = 2f; // Projectile scale multiplier
            Projectile.penetrate = 1; // How many hits projectile have to make before it dies. 3 means projectile will die on 3rd enemy. Setting this to 0 will make projectile die instantly
            Projectile.aiStyle = 171; // AI style of a projectile. 0 is default bullet AI
            Projectile.width = Projectile.height = 10; // Hitbox of projectile in pixels
            Projectile.friendly = true; // Can hit enemies?
            Projectile.hostile = false; // Can hit player?
            Projectile.timeLeft = 350; // Time in ticks before projectile dies
            Projectile.light = 0.3f; // How much light projectile provides
            Projectile.ignoreWater = false; // Does the projectile ignore water (doesn't slow down in it)
            Projectile.tileCollide = true; // Does the projectile collide with tiles, like blocks?
            Projectile.alpha = 0; // Completely transparent
        }
        public override string Texture => "TanusBetterVanilla/Content/Projectiles/CultistVoid"; // We will use no texture

        public override void AI() // This hook updates every tick
        {
            Projectile.alpha = 0;
            Projectile.rotation += 0.1f;
            if (Main.netMode != NetmodeID.Server) // Do not spawn dust on server!
            {
                Dust dust = Dust.NewDustPerfect(
                Projectile.Center,
                DustID.ShimmerTorch,           // Use DustID.Torch for a fiery effect
                Vector2.Zero,
                100,
                Color.Violet,
                3f
                );
                dust.noGravity = true;
                dust.fadeIn = 0.5f;
            }
        }

        public override void OnKill(int timeLeft)
        {
            // Play explosion sound
            SoundEngine.PlaySound(SoundID.Item14, Projectile.Center);

            int numDust = 30;
            for (int i = 0; i < numDust; i++)
            {
                // Random direction and speed
                Vector2 velocity = Main.rand.NextVector2Circular(4f, 4f);
                Dust dust = Dust.NewDustPerfect(
                Projectile.Center,
                DustID.ShimmerTorch,           // Use DustID.Torch for a fiery effect
                Vector2.Zero,
                100,
                Color.Violet,
                3f                    // Larger scale for a ball-like effect
            );
                dust.noGravity = true;
                dust.fadeIn = 1f;
            }

            int explosionRadius = 60;
            int explosionDamage = (int)(Projectile.damage * 1.5);
            for (int k = 0; k < Main.maxNPCs; k++)
            {
                NPC npc = Main.npc[k];
                if (npc.active && !npc.friendly && npc.Distance(Projectile.Center) < explosionRadius)
                {
                    int direction = npc.Center.X > Projectile.Center.X ? 1 : -1;
                    NPC.HitInfo hitInfo = new NPC.HitInfo()
                    {
                        Damage = explosionDamage,
                        Knockback = 0f,
                        HitDirection = direction,
                        Crit = false
                    };
                    npc.StrikeNPC(hitInfo);
                }
            }
        }

        public override void OnSpawn(Terraria.DataStructures.IEntitySource source)
        {
            int numDust = 20;
            for (int i = 0; i < numDust; i++) // Loop through code below numDust times
            {
                Vector2 velocity = Vector2.One.RotatedBy(MathHelper.ToRadians(360 / numDust * i)); // Circular velocity
                Dust.NewDustPerfect(Projectile.Center, DustID.FlameBurst, velocity).noGravity = true; // Creating dust
            }
        }

        public override void OnHitNPC(NPC target, NPC.HitInfo hit, int damageDone)
        {
            int shadowflameID = 153;
            int sparkleID = 320;
            target.buffImmune[shadowflameID] = false;
            target.buffImmune[sparkleID] = false;
            target.AddBuff(shadowflameID, 300);
            target.AddBuff(sparkleID, 300);
        }
    }
}

