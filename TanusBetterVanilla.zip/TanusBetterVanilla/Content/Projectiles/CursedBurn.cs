using Terraria;
using Terraria.ModLoader;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Terraria.DataStructures;
using Terraria.Audio;

namespace TanusBetterVanilla.Content.Projectiles
{
    public class CursedBurn : ModProjectile
    {
        public override void SetDefaults()
        {
            Projectile.DamageType = DamageClass.Ranged; // Damage class projectile uses
            Projectile.scale = 2f; // Projectile scale multiplier
            Projectile.penetrate = 2; // How many hits projectile have to make before it dies. 3 means projectile will die on 3rd enemy. Setting this to 0 will make projectile die instantly
            Projectile.aiStyle = 0; // AI style of a projectile. 0 is default bullet AI
            Projectile.width = Projectile.height = 10; // Hitbox of projectile in pixels
            Projectile.friendly = true; // Can hit enemies?
            Projectile.hostile = false; // Can hit player?
            Projectile.timeLeft = 15; // Time in ticks before projectile dies
            Projectile.light = 0.3f; // How much light projectile provides
            Projectile.ignoreWater = true; // Does the projectile ignore water (doesn't slow down in it)
            Projectile.tileCollide = true; // Does the projectile collide with tiles, like blocks?
            Projectile.alpha = 255; // Completely transparent
        }
        public override string Texture => "Terraria/Images/Projectile_0"; // We will use no texture

        public override void AI()
        {
            if (Main.netMode != NetmodeID.Server)
            {
                // Main flame particle
                Dust mainDust = Dust.NewDustPerfect(
                    Projectile.Center,
                    DustID.CursedTorch,
                    Projectile.velocity * 0.2f,
                    150,
                    Color.LimeGreen,
                    2f * Projectile.scale
                );
                mainDust.noGravity = true;
                mainDust.fadeIn = 0.7f;

                // Additional aesthetic particles
                for (int i = 0; i < 3; i++)
                {
                    Vector2 offset = new Vector2(
                        Main.rand.NextFloat(-8f, 8f),
                        Main.rand.NextFloat(-8f, 8f)
                    );
                    Dust extraDust = Dust.NewDustPerfect(
                        Projectile.Center + offset,
                        DustID.CursedTorch,
                        Projectile.velocity * 0.1f,
                        200,
                        Color.GreenYellow,
                        1.2f * Projectile.scale
                    );
                    extraDust.noGravity = true;
                    extraDust.fadeIn = 0.9f;
                }
            }

            // Increase projectile size gradually
            Projectile.scale += 0.2f; // Adjust growth rate as needed

            // Optional: make the projectile fade out over time
            Projectile.alpha += 5;

        }

        public override void OnHitNPC(NPC target, NPC.HitInfo hit, int damageDone)
        {
            // Apply Cursed Inferno debuff for 2 seconds (120 ticks)
            target.AddBuff(BuffID.CursedInferno, 120);
        }
    }
}