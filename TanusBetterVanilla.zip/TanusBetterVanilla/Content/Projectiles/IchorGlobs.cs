using Terraria;
using Terraria.ModLoader;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Terraria.DataStructures;
using Terraria.Audio;
using System;

namespace TanusBetterVanilla.Content.Projectiles
{
    public class IchorGlobs : ModProjectile
    {
        public override void SetDefaults()
        {
            Projectile.DamageType = DamageClass.Ranged;
            Projectile.width = Projectile.height = 3; // More ball-like
            Projectile.scale = 3f;
            Projectile.penetrate = 1;
            Projectile.aiStyle = 0;
            Projectile.friendly = true;
            Projectile.hostile = false;
            Projectile.timeLeft = 6000;
            Projectile.light = 0.2f;
            Projectile.ignoreWater = false;
            Projectile.tileCollide = true;
            Projectile.alpha = 25;
        }

        public override string Texture => "TanusBetterVanilla/Content/Projectiles/IchorGlob";

        public override void AI()
        {
            // Gravity effect
            Projectile.velocity.Y += 0.25f;

            // Random wobble for a "sludge" feel
            Projectile.velocity.X += Main.rand.NextFloat(-0.05f, 0.05f);

            // Subtle ichor dust (centered on sprite, scales with projectile)
            if (Main.netMode != NetmodeID.Server)
            {
                Vector2 visualCenter = Projectile.position + new Vector2(Projectile.width, Projectile.height) / 2f;

                Dust dust = Dust.NewDustPerfect(
                    visualCenter,
                    DustID.Ichor,
                    Vector2.Zero,
                    50,
                    Color.Yellow,
                    Projectile.scale * 1.2f // Thicker trail
                );
                dust.noGravity = true;
                dust.fadeIn = 0f;
            }
        }

        // Make the glob bounce off tiles
        public override bool OnTileCollide(Vector2 oldVelocity)
        {
            if (Projectile.velocity.Y > 1f)
            {
                Projectile.velocity.Y = -oldVelocity.Y * 0.6f; // Bounce, lose speed
            }
            if (Math.Abs(Projectile.velocity.X) > 0.1f)
            {
                Projectile.velocity.X = -oldVelocity.X * 0.7f; // Bounce, lose speed
            }
            // Reduce penetration so it eventually disappears
            Projectile.penetrate--;
            // Kill if out of bounces
            return Projectile.penetrate <= 0;
        }

        public override void OnHitNPC(NPC target, NPC.HitInfo hit, int damageDone)
        {
            target.AddBuff(BuffID.Ichor, 300);
        }
    }
}