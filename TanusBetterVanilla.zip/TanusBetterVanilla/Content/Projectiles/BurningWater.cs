using Terraria;
using Terraria.ModLoader;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Terraria.DataStructures;
using Terraria.Audio;
using System;

namespace TanusBetterVanilla.Content.Projectiles
{
    public class BurningWater : ModProjectile
    {
        public override void SetDefaults()
        {
            Projectile.DamageType = DamageClass.Ranged;
            Projectile.width = Projectile.height = 3; // More ball-like
            Projectile.scale = 3f;
            Projectile.penetrate = 10;
            Projectile.aiStyle = 0;
            Projectile.friendly = true;
            Projectile.hostile = false;
            Projectile.timeLeft = 4000;
            Projectile.light = 0.2f;
            Projectile.ignoreWater = false;
            Projectile.tileCollide = true;
            Projectile.alpha = 255;
        }

        public override string Texture => "TanusBetterVanilla/Content/Projectiles/IchorGlob";

        public override void AI()
        {
            // Gravity effect
            Projectile.velocity.Y += 0.25f;

            // Random wobble for a "sludge" feel
            Projectile.velocity.X += Main.rand.NextFloat(-0.05f, 0.05f);

            // Subtle ichor dust (centered on sprite, scales with projectile)
            if (Main.netMode != NetmodeID.Server)
            {
                Vector2 visualCenter = Projectile.position + new Vector2(Projectile.width, Projectile.height) / 2f;

                Dust dust = Dust.NewDustPerfect(
                    visualCenter,
                    DustID.Water,
                    Vector2.Zero,
                    50,
                    Color.Blue,
                    Projectile.scale * 1.2f // Thicker trail
                );
                dust.noGravity = true;
                dust.fadeIn = 0f;

                Dust fireDust = Dust.NewDustPerfect(
                Projectile.Center + Main.rand.NextVector2Circular(4f, 4f),
                DustID.Torch,
                Projectile.velocity * 0.2f,
                100,
                Color.Orange,
                1.9f
                );
                fireDust.noGravity = true;
            }
        }
        public override void OnHitNPC(NPC target, NPC.HitInfo hit, int damageDone)
        {
            target.AddBuff(BuffID.Burning, 300);
        }
    }
}