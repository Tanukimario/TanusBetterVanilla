using Terraria;
using Terraria.ModLoader;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria.DataStructures;
using Terraria.Audio;
using System;

namespace TanusBetterVanilla.Content.Projectiles
{
    public class PocketSunProjectile : ModProjectile
    {
        public override void SetDefaults()
        {
            Projectile.CloneDefaults(ProjectileID.RedsYoyo); // Übernimmt Standard-Yoyo-Verhalten
            Projectile.scale = 0.5f;
            Projectile.width = 32;
            Projectile.height = 32;
            Projectile.light = 0.5f;
            Projectile.aiStyle = ProjAIStyleID.Yoyo;
            AIType = ProjectileID.RedsYoyo; // Wichtig für korrektes Verhalten
        }
        public override void OnHitNPC(NPC target, NPC.HitInfo hit, int damageDone)
        {
            Projectile.NewProjectile(
                target.GetSource_OnHit(target),
                target.Center,
                new Vector2(0, -5f),
                ModContent.ProjectileType<SunCombustion>(),
                20,
                1f,
                Projectile.damage,
                Projectile.knockBack,
                Projectile.owner
            );

            int numShards = 1;
            float shootSpeed = 3f;
            for (int i = 0; i < numShards; i++)
            {
                Vector2 velocity = Vector2.One.RotatedBy(Main.rand.Next(1, 361)); // Circular velocity
                Projectile.NewProjectile(
                    Projectile.GetSource_FromThis(),
                    Projectile.Center,
                    velocity * shootSpeed,
                    ModContent.ProjectileType<SolarWind>(),
                    Projectile.damage,
                    Projectile.knockBack,
                    Projectile.owner
                );
            }

            int ID = 189;
            target.buffImmune[ID] = false;
            target.AddBuff(ID, 300);
        }
        public override string Texture => "TanusBetterVanilla/Content/Projectiles/PocketSunProjectile";
    }
}