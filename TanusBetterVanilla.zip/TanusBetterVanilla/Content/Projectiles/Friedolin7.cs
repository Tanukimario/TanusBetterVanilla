using Terraria;
using Terraria.ModLoader;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria.DataStructures;
using Terraria.Audio;
using System;

namespace TanusBetterVanilla.Content.Projectiles
{
    public class Friedolin7 : ModProjectile
    {
        public override string Texture => "Terraria/Images/Projectile_0"; // We will use no texture
        public override void SetDefaults()
        {
            Projectile.DamageType = DamageClass.Magic; // Damage class projectile uses
            Projectile.scale = 1f; // Projectile scale multiplier
            Projectile.penetrate = 300; // How many hits projectile have to make before it dies. 3 means projectile will die on 3rd enemy. Setting this to 0 will make projectile die instantly
            Projectile.aiStyle = 1; // AI style of a projectile. 0 is default bullet AI
            AIType = ProjectileID.Bullet;
            Projectile.width = Projectile.height = 10; // Hitbox of projectile in pixels
            Projectile.friendly = true; // Can hit enemies?
            Projectile.hostile = false; // Can hit player?
            Projectile.timeLeft = 180; // Time in ticks before projectile dies
            Projectile.light = 0.3f; // How much light projectile provides
            Projectile.ignoreWater = true; // Does the projectile ignore water (doesn't slow down in it)
            Projectile.tileCollide = true; // Does the projectile collide with tiles, like blocks?
            Projectile.alpha = 255; // Completely transparent
        }

        public override void AI() // This hook updates every tick
        {
            if (Main.netMode != NetmodeID.Server) // Do not spawn dust on server!
            {
                Dust dust = Dust.NewDustPerfect(
                    Position: Projectile.Center,
                    Type: DustID.PinkTorch,
                    Velocity: Vector2.Zero,
                    Alpha: 100,
                    newColor: Color.Pink,
                    Scale: 1.5f
                    );
                dust.noGravity = true; // Dust don't have gravity
                dust.fadeIn = -1f;
            }
        }

        public override void OnKill(int timeLeft) // What happens on projectile death
        {
            int numDust = 20;
            for (int i = 0; i < numDust; i++) // Loop through code below numDust times
            {
                Vector2 velocity = Vector2.One.RotatedBy(MathHelper.ToRadians(360 / numDust * i)); // Circular velocity
                Dust.NewDustPerfect(Projectile.Center, DustID.PinkTorch, velocity).noGravity = true; // Creating dust
            }
        }

        public override void OnHitNPC(NPC target, NPC.HitInfo hit, int damageDone)
        {
            if (Main.rand.NextBool(8)) // 1/4 chance, or 25% in other words
            {
                int ID = 320;
                target.buffImmune[ID] = false;  // Immunität aufheben
                target.AddBuff(ID, 300);
            }
        }
    }
}