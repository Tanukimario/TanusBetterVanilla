using Terraria;
using Terraria.ModLoader;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Terraria.DataStructures;
using Terraria.Audio;

namespace TanusBetterVanilla.Content.Projectiles
{
    public class Thundercloud : ModProjectile
    {
        public override void SetDefaults()
        {
            Projectile.DamageType = DamageClass.Ranged; // Damage class projectile uses
            Projectile.scale = 2f; // Projectile scale multiplier
            Projectile.penetrate = 200; // How many hits projectile have to make before it dies. 3 means projectile will die on 3rd enemy. Setting this to 0 will make projectile die instantly
            Projectile.aiStyle = 0; // AI style of a projectile. 0 is default bullet AI
            Projectile.width = Projectile.height = 10; // Hitbox of projectile in pixels
            Projectile.friendly = true; // Can hit enemies?
            Projectile.hostile = false; // Can hit player?
            Projectile.timeLeft = 30; // Time in ticks before projectile dies
            Projectile.light = 0.3f; // How much light projectile provides
            Projectile.ignoreWater = true; // Does the projectile ignore water (doesn't slow down in it)
            Projectile.tileCollide = true; // Does the projectile collide with tiles, like blocks?
            Projectile.alpha = 25; // Completely transparent
        }
        public override string Texture => "Terraria/Images/Projectile_0"; // We will use no texture

        public override void AI()
        {
            if (Main.netMode != NetmodeID.Server)
            {
                Vector2 mainOffset = new Vector2(
                    Main.rand.NextFloat(-8f, 8f),
                    Main.rand.NextFloat(-8f, 8f)
                );
                Dust mainDust = Dust.NewDustPerfect(
                        Projectile.Center + mainOffset,
                        DustID.BlueTorch,
                        Projectile.velocity * 0.5f,
                        200,
                        Color.DarkBlue,
                        3f * Projectile.scale
                    );
                mainDust.noGravity = true;
                mainDust.fadeIn = 0.9f;
                mainDust.velocity += Projectile.velocity * 0.5f;

                // Additional aesthetic particles
                for (int i = 0; i < 3; i++)
                {
                    Vector2 offset = new Vector2(
                        Main.rand.NextFloat(-8f, 8f),
                        Main.rand.NextFloat(-8f, 8f)
                    );
                    Dust extraDust = Dust.NewDustPerfect(
                        Projectile.Center + offset,
                        DustID.MushroomTorch,
                        Projectile.velocity * 0.1f,
                        200,
                        Color.LightBlue,
                        0.9f * Projectile.scale
                    );
                    extraDust.noGravity = true;
                    extraDust.fadeIn = 0.9f;
                }

                Vector2 shockOffset = new Vector2(
                    Main.rand.NextFloat(-8f, 8f),
                    Main.rand.NextFloat(-8f, 8f)
                );
                Dust shockDust = Dust.NewDustPerfect(
                    Projectile.Center,
                    DustID.Electric,
                    Projectile.velocity * 0.2f,
                    150,
                    new Color(50, 100, 255), // Intensiv leuchtendes Blau
                    0.9f
                );
                shockDust.noGravity = false;
                shockDust.fadeIn = 0.8f;
                shockDust.noLight = false;

            }

            // Increase projectile size gradually
            Projectile.scale += 0.2f; // Adjust growth rate as needed

            // Optional: make the projectile fade out over time
            Projectile.alpha += 5;

        }

        public override void OnHitNPC(NPC target, NPC.HitInfo hit, int damageDone)
        {
            int confusedID = 31;
            target.buffImmune[confusedID] = false;  // Immunität aufheben
            target.AddBuff(confusedID, 300);
        }
    }
}