using Terraria;
using Terraria.ModLoader;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Terraria.DataStructures;
using Terraria.Audio;

namespace TanusBetterVanilla.Content.Projectiles
{
    public class CorruptHarvest : ModProjectile
    {
        public override void SetDefaults()
        {
            Projectile.DamageType = DamageClass.Melee; // Damage class projectile uses
            Projectile.scale = 2f; // Projectile scale multiplier
            Projectile.penetrate = 1; // How many hits projectile have to make before it dies. 3 means projectile will die on 3rd enemy. Setting this to 0 will make projectile die instantly
            Projectile.aiStyle = 0; // AI style of a projectile. 0 is default bullet AI
            Projectile.width = Projectile.height = 10; // Hitbox of projectile in pixels
            Projectile.friendly = true; // Can hit enemies?
            Projectile.hostile = false; // Can hit player?
            Projectile.timeLeft = 1; // Time in ticks before projectile dies
            Projectile.light = 0; // How much light projectile provides
            Projectile.ignoreWater = true; // Does the projectile ignore water (doesn't slow down in it)
            Projectile.tileCollide = false; // Does the projectile collide with tiles, like blocks?
            Projectile.alpha = 255; // Completely transparent
        }
        public override string Texture => "Terraria/Images/Projectile_0"; // We will use no texture
        public override void OnKill(int timeLeft)
        {
            // Play explosion sound
            SoundEngine.PlaySound(SoundID.Item14, Projectile.Center);

            int numDust = 10;
            for (int i = 0; i < numDust; i++)
            {
                // Random direction and speed
                Vector2 velocity = Main.rand.NextVector2Circular(4f, 4f);
                Dust dust = Dust.NewDustPerfect(
                    Projectile.Center,
                    DustID.PurpleMoss, // Fiery dust
                    velocity,
                    150,
                    Color.Violet,
                    1.25f // Large fiery particles
                );
                dust.noGravity = true;
                dust.fadeIn = 1f;
            }
        }
    }
}