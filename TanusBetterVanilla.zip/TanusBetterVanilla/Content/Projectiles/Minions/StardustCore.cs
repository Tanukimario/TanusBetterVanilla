using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.DataStructures;
using Terraria.Audio;
using Microsoft.Xna.Framework;
using Terraria.GameContent.ItemDropRules;
using TanusBetterVanilla.Content.Projectiles;
using TanusBetterVanilla.Content.Projectiles.Minions;
using TanusBetterVanilla.Content.Buffs;
using System;
using System.Collections.Generic;


namespace TanusBetterVanilla.Content.Projectiles.Minions
{
    public class StardustCore : ModProjectile
    {
        private int shootTimer;
        public override void SetStaticDefaults()
        {
            Main.projFrames[Projectile.type] = 1;
            Main.projPet[Projectile.type] = true;
            ProjectileID.Sets.MinionTargettingFeature[Projectile.type] = true;
        }

        public override void SetDefaults()
        {
            Projectile.width = 32;
            Projectile.height = 32;
            Projectile.friendly = true;
            Projectile.minion = true;
            Projectile.minionSlots = 1f;
            Projectile.penetrate = -1;
            Projectile.tileCollide = false;
            Projectile.ignoreWater = true;
            Projectile.timeLeft = 18000;
        }

        public override void AI()
        {
            Player player = Main.player[Projectile.owner];

            // Kill Minion wenn Spieler tot oder kein Buff mehr
            if (!player.active || player.dead || !player.HasBuff(ModContent.BuffType<Buffs.StardustCoreBuff>()))
            {
                Projectile.Kill();
                return;
            }

            // Verlängere Lebenszeit kontinuierlich
            Projectile.timeLeft = 2;

            // Positioniere über dem Kopf des Spielers (leicht versetzt)
            Vector2 idlePosition = player.Center + new Vector2(0f, -60f);
            float inertia = 1f;
            Vector2 direction = idlePosition - Projectile.Center;
            Projectile.velocity = direction / inertia;

            Lighting.AddLight(Projectile.Center, 0.3f, 0.0f, 0.7f); // RGB: Violett

            // ✨ Magische Partikel
            if (Main.rand.NextBool(5)) // 1/5 Chance pro Tick
            {
                Dust dust = Dust.NewDustDirect(Projectile.position, Projectile.width, Projectile.height, DustID.IceTorch);
                dust.velocity *= 0.3f;
                dust.scale = 1.2f;
                dust.noGravity = true;
            }

            // Zielsuche
            NPC target = null;
            float maxDetectDistance = 1000f;

            for (int i = 0; i < Main.maxNPCs; i++)
            {
                NPC npc = Main.npc[i];
                if (npc.CanBeChasedBy(this) && Vector2.Distance(Projectile.Center, npc.Center) < maxDetectDistance)
                {
                    maxDetectDistance = Vector2.Distance(Projectile.Center, npc.Center);
                    target = npc;
                }
            }

            // Angriff: Projektil feuern
            shootTimer++;
            if (target != null && shootTimer >= 30) // alle 60 Ticks (1 Sekunde)
            {
                shootTimer = 0;
                Vector2 shootDirection = (target.Center - Projectile.Center).SafeNormalize(Vector2.UnitY);
                float shootSpeed = 8f;

                // Projektil abschießen
                Projectile.NewProjectile(
                    Projectile.GetSource_FromThis(),
                    Projectile.Center,
                    shootDirection * shootSpeed,
                    ModContent.ProjectileType<StardustBolt>(),
                    Projectile.damage,
                    Projectile.knockBack,
                    Projectile.owner
                );

                // Soundeffekt
                SoundEngine.PlaySound(SoundID.Item20, Projectile.position);
            }

            // Animation (falls mehrere Frames)
            Projectile.rotation = 0f; // kein Drehen
        }
    }
}