using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.GameContent;
using Terraria.GameContent.Bestiary;
using Terraria.GameContent.ItemDropRules;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;

namespace TanusBetterVanilla.Content.NPCs
{
    public class MagmaSlime : ModNPC
    {
        public override void SetDefaults()
        {
            NPC.width = 32;
            NPC.height = 32;
            NPC.damage = 75;
            NPC.defense = 15;
            NPC.lifeMax = 500;
            NPC.HitSound = SoundID.NPCHit36;
            NPC.DeathSound = SoundID.NPCDeath39;
            NPC.friendly = false;
            NPC.value = 60f;
            NPC.knockBackResist = 0.5f;
            NPC.aiStyle = 1;
            AnimationType = NPCID.BlueSlime;
            NPC.lavaImmune = true;
            NPC.buffImmune[BuffID.OnFire] = true;
            NPC.buffImmune[BuffID.OnFire3] = true; // z. B. "Hellfire"
            NPC.buffImmune[BuffID.CursedInferno] = true;
            NPC.buffImmune[BuffID.Burning] = true;
        }

        public override void FindFrame(int frameHeight)
        {
            NPC.frameCounter += 5;
            if (NPC.frameCounter >= Main.npcFrameCount[NPC.type])
            {
                NPC.frameCounter = 0;
            }

            int frame = (int)NPC.frameCounter;
            NPC.frame = new Rectangle(frame * 32, 0, 32, 32); // x, y, Breite, Höhe
        }

        public override void SetStaticDefaults()
        {
            Main.npcFrameCount[NPC.type] = 4; // 4 Animationsframes horizontal
        }

        public override float SpawnChance(NPCSpawnInfo spawnInfo)
        {
            Player player = spawnInfo.Player;

            bool inHellLayer = spawnInfo.SpawnTileY >= Main.rockLayer && spawnInfo.SpawnTileY < Main.maxTilesY - 200;
            bool isHardmode = Main.hardMode;

            if (isHardmode && player.ZoneUnderworldHeight)
            {
                return 0.25f;
            }

            return 0f;
        }
        public override bool PreDraw(SpriteBatch spriteBatch, Vector2 screenPos, Color drawColor)
        {
            Vector2 drawPosition = NPC.Center - screenPos;
            drawPosition.Y += 0f; // Vertikal verschieben, falls nötig

            Rectangle frame = NPC.frame;
            Vector2 origin = new Vector2(frame.Width / 2f, frame.Height / 2f);

            spriteBatch.Draw(
                TextureAssets.Npc[NPC.type].Value,
                drawPosition,
                frame,
                drawColor,
                NPC.rotation,
                origin,
                NPC.scale,
                SpriteEffects.None,
                0f
            );

            return false; // verhindert Standardzeichnung
        }
        public override void AI()
        {
            if (Main.rand.NextBool(2)) // 1/5 Chance pro Tick
            {
                Dust dust = Dust.NewDustDirect(NPC.position, NPC.width, NPC.height, DustID.Torch);
                dust.velocity *= 0.3f;
                dust.scale = 1.2f;
                dust.noGravity = true;
            }
        }

        public override void ModifyNPCLoot(NPCLoot npcLoot)
        {
            npcLoot.Add(ItemDropRule.Common(2701, 1, 25, 60)); //Living Fire
            npcLoot.Add(ItemDropRule.Common(1322, 50)); //Magma Stone
            npcLoot.Add(ItemDropRule.Common(3282, 500)); //Cascade
            npcLoot.Add(ItemDropRule.Common(3290, 300)); //Hel-Fire
        }
    }
}