using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.DataStructures;
using Microsoft.Xna.Framework;
using Terraria.GameContent.ItemDropRules;
using TanusBetterVanilla.Content.Projectiles;
using TanusBetterVanilla.Content.Projectiles.Minions;
using TanusBetterVanilla.Content.Buffs;
using System;
using System.Collections.Generic;


namespace TanusBetterVanilla.Content.Buffs
{
    public class ShadowflamePortalBuff : ModBuff
    {
        public override void SetStaticDefaults()
        {
            Main.buffNoTimeDisplay[Type] = true;
            Main.vanityPet[Type] = false;
        }

        public override void Update(Player player, ref int buffIndex)
        {
            if (player.ownedProjectileCounts[ModContent.ProjectileType<Projectiles.Minions.ShadowflamePortal>()] > 0)
            {
                player.buffTime[buffIndex] = 18000;
            }
            else
            {
                player.DelBuff(buffIndex);
                buffIndex--;
            }
        }
    }
}