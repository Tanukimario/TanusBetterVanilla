using Microsoft.Xna.Framework;
using TanusBetterVanilla.Content.Items.Materials;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using TanusBetterVanilla.Content.Projectiles;

namespace TanusBetterVanilla.Content.Items.Weapons.Ranged
{
    public class HellsInferno : ModItem
    {
        public override void SetDefaults()
        {
            // Visual properties
            Item.width = 60;
            Item.height = 20;
            Item.scale = 1.9f;
            Item.useStyle = ItemUseStyleID.Shoot; // Use style for guns
            Item.rare = ItemRarityID.Green;

            // Combat properties
            Item.damage = 34; // Gun damage + bullet damage = final damage
            Item.DamageType = DamageClass.Ranged;
            Item.useTime = 3; // Delay between shots.
            Item.useAnimation = 3; // How long shoot animation lasts in ticks.
            Item.knockBack = 0.3f; // Gun knockback + bullet knockback = final knockback
            Item.autoReuse = true;
            Item.reuseDelay = 6; // How long the gun will be unable to shoot after useAnimation ends

            // Other properties
            Item.value = 5000;
            Item.UseSound = SoundID.Item34; // Gun use sound

            // Gun properties
            Item.noMelee = true; // Item not dealing damage while held, we don’t hit mobs in the head with a gun
            Item.shoot = ModContent.ProjectileType<HellflameBurst>(); // What kind of projectile the gun fires, does not mean anything here because it is replaced by ammo
            Item.shootSpeed = 24f; // Speed of a projectile. Mainly measured by eye
            Item.useAmmo = AmmoID.Gel; // What ammo gun uses
        }
        public override void AddRecipes()
        {
            CreateRecipe()
            .AddIngredient(ItemID.HellstoneBar, 16) // Use ItemID for vanilla items
            .AddIngredient(ItemID.Obsidian, 17)
            .AddIngredient(ItemID.LavaBucket, 2)
            .AddTile(TileID.Hellforge) // Use TileID for vanilla tiles
            .Register();
        }

        public override Vector2? HoldoutOffset() => new Vector2(-0.75f, -5f); // Offset in pixels at which the player will hold the gun. -Y is up
        public override bool CanConsumeAmmo(Item ammo, Player player) => Main.rand.Next(101) <= 20; // Chance in % to not consume ammo
    }
}