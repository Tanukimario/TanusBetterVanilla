using Microsoft.Xna.Framework;
using TanusBetterVanilla.Content.Items.Materials;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using TanusBetterVanilla.Content.Projectiles;

namespace TanusBetterVanilla.Content.Items.Weapons.Ranged
{
    public class Flarethrower : ModItem
    {
        public override void SetDefaults()
        {
            // Visual properties
            Item.width = 60;
            Item.height = 20;
            Item.scale = 1.9f;
            Item.useStyle = ItemUseStyleID.Shoot; // Use style for guns
            Item.rare = ItemRarityID.Blue;

            // Combat properties
            Item.damage = 22; // Gun damage + bullet damage = final damage
            Item.DamageType = DamageClass.Ranged;
            Item.useTime = 25; // Delay between shots.
            Item.useAnimation = 25; // How long shoot animation lasts in ticks.
            Item.knockBack = 0.3f; // Gun knockback + bullet knockback = final knockback
            Item.autoReuse = true;
            Item.reuseDelay = 6; // How long the gun will be unable to shoot after useAnimation ends

            // Other properties
            Item.value = 15000;
            Item.UseSound = SoundID.Item34; // Gun use sound

            // Gun properties
            Item.noMelee = true; // Item not dealing damage while held, we don’t hit mobs in the head with a gun
            Item.shoot = ModContent.ProjectileType<FlareBurst>(); // What kind of projectile the gun fires, does not mean anything here because it is replaced by ammo
            Item.shootSpeed = 24f; // Speed of a projectile. Mainly measured by eye
            Item.useAmmo = AmmoID.Gel; // What ammo gun uses
        }
        public override void AddRecipes()
        {
            CreateRecipe()
            .AddIngredient(ItemID.FlareGun, 1) // Use ItemID for vanilla items
            .AddIngredient(ItemID.IronBar, 12)
            .AddIngredient(ItemID.Ruby, 3)
            .AddTile(TileID.Anvils) // Use TileID for vanilla tiles
            .Register();

            CreateRecipe()
            .AddIngredient(ItemID.FlareGun, 1) // Use ItemID for vanilla items
            .AddIngredient(ItemID.LeadBar, 12)
            .AddIngredient(ItemID.Ruby, 3)
            .AddTile(TileID.Anvils) // Use TileID for vanilla tiles
            .Register();
        }

        public override Vector2? HoldoutOffset() => new Vector2(-0.75f, -5f); // Offset in pixels at which the player will hold the gun. -Y is up
        public override bool CanConsumeAmmo(Item ammo, Player player) => Main.rand.Next(101) <= 20; // Chance in % to not consume ammo
    }
}