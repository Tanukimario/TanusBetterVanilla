using Microsoft.Xna.Framework;
using TanusBetterVanilla.Content.Items.Materials;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace TanusBetterVanilla.Content.Items.Weapons.Ranged
{
    public class SilverShotgun : ModItem
    {
        public override void SetDefaults()
        {
            // Visual properties
            Item.width = 60;
            Item.height = 20;
            Item.scale = 1.5f;
            Item.useStyle = ItemUseStyleID.Shoot; // Use style for guns
            Item.rare = ItemRarityID.Blue;

            // Combat properties
            Item.damage = 15; // Gun damage + bullet damage = final damage
            Item.DamageType = DamageClass.Ranged;
            Item.useTime = 10; // Delay between shots.
            Item.useAnimation = 30; // How long shoot animation lasts in ticks.
            Item.knockBack = 4.5f; // Gun knockback + bullet knockback = final knockback
            Item.autoReuse = false;
            Item.reuseDelay = 25; // How long the gun will be unable to shoot after useAnimation ends
            Item.consumeAmmoOnLastShotOnly = true; // Gun will consume only one ammo per a burst of shots

            // Other properties
            Item.value = 1000;
            Item.UseSound = SoundID.Item11; // Gun use sound

            // Gun properties
            Item.noMelee = true; // Item not dealing damage while held, we don’t hit mobs in the head with a gun
            Item.shoot = ProjectileID.PurificationPowder; // What kind of projectile the gun fires, does not mean anything here because it is replaced by ammo
            Item.shootSpeed = 16f; // Speed of a projectile. Mainly measured by eye
            Item.useAmmo = AmmoID.Bullet; // What ammo gun uses
        }
        public override void AddRecipes()
        {
            CreateRecipe()
            .AddIngredient(ItemID.SilverBar, 12) // Use ItemID for vanilla items
            .AddIngredient(ItemID.Wood, 7)
            .AddTile(TileID.Anvils)
            .Register();
        }

        public override Vector2? HoldoutOffset() => new Vector2(-0.75f, -10f); // Offset in pixels at which the player will hold the gun. -Y is up
        public override bool CanConsumeAmmo(Item ammo, Player player) => Main.rand.Next(101) <= 33; // Chance in % to not consume ammo
        public override bool Shoot(Player player, EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
        {
            int numProjectiles = Main.rand.Next(1, 4); // 1 to 3 projectiles
            for (int i = 0; i < numProjectiles; i++)
            {
                Vector2 perturbedVelocity = velocity.RotatedByRandom(MathHelper.ToRadians(10)); // Spread
                Projectile.NewProjectile(
                    source,
                    position,
                    perturbedVelocity,
                    type,
                    damage,
                    knockback,
                    player.whoAmI
                );
            }
            return false; // Prevent default projectile
        }



    }
}

