using Microsoft.Xna.Framework;
using TanusBetterVanilla.Content.Items.Materials;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace TanusBetterVanilla.Content.Items.Weapons.Ranged
{
    public class SerpentsShot : ModItem
    {
        public override void SetDefaults()
        {
            // Visual properties
            Item.width = 60;
            Item.height = 20;
            Item.scale = 0.8f;
            Item.useStyle = ItemUseStyleID.Shoot; // Use style for guns
            Item.rare = ItemRarityID.Orange;

            // Combat properties
            Item.damage = 15; // Gun damage + bullet damage = final damage
            Item.DamageType = DamageClass.Ranged;
            Item.useTime = 5; // Delay between shots.
            Item.useAnimation = 15; // How long shoot animation lasts in ticks.
            Item.knockBack = 4.5f; // Gun knockback + bullet knockback = final knockback
            Item.autoReuse = false;
            Item.reuseDelay = 15; // How long the gun will be unable to shoot after useAnimation ends
            Item.consumeAmmoOnLastShotOnly = true; // Gun will consume only one ammo per a burst of shots

            // Other properties
            Item.value = 1000;
            Item.UseSound = SoundID.Item11; // Gun use sound

            // Gun properties
            Item.noMelee = true; // Item not dealing damage while held, we don’t hit mobs in the head with a gun
            Item.shoot = ProjectileID.Bullet; // What kind of projectile the gun fires, does not mean anything here because it is replaced by ammo
            Item.shootSpeed = 16f; // Speed of a projectile. Mainly measured by eye
            Item.useAmmo = AmmoID.Bullet; // What ammo gun uses
        }
        public override void AddRecipes()
        {
            CreateRecipe()
            .AddIngredient(ModContent.ItemType<AzueriteBar>(), 16)
            .AddTile(TileID.Anvils)
            .Register();
        }
        public override bool CanConsumeAmmo(Item ammo, Player player) => Main.rand.Next(101) <= 15; // Chance in % to not consume ammo
        
        public override Vector2? HoldoutOffset() => new Vector2(-2.25f, 0f); // Offset in pixels at which the player will hold the gun. -Y is up
    }
}

