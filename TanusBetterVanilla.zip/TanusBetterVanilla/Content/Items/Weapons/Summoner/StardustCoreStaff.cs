using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.DataStructures;
using Microsoft.Xna.Framework;
using Terraria.GameContent.ItemDropRules;
using TanusBetterVanilla.Content.Projectiles;
using TanusBetterVanilla.Content.Projectiles.Minions;
using TanusBetterVanilla.Content.Buffs;
using System;
using System.Collections.Generic;

namespace TanusBetterVanilla.Content.Items.Weapons.Summoner
{
    public class StardustCoreStaff : ModItem
    {
        public override void SetStaticDefaults()
        {
            ItemID.Sets.GamepadWholeScreenUseRange[Item.type] = true;
            ItemID.Sets.LockOnIgnoresCollision[Item.type] = true;

            // Das Item wird als "Summon Staff" behandelt
            Item.staff[Item.type] = true;
        }

        public override void SetDefaults()
        {
            Item.damage = 95;
            Item.DamageType = DamageClass.Summon;
            Item.mana = 10;
            Item.width = 40;
            Item.height = 40;
            Item.useTime = 36;
            Item.useAnimation = 36;
            Item.useStyle = ItemUseStyleID.Swing;
            Item.noMelee = true;
            Item.knockBack = 2f;
            Item.value = Item.buyPrice(gold: 1);
            Item.rare = ItemRarityID.Red;
            Item.UseSound = SoundID.Item44;

            Item.shoot = ModContent.ProjectileType<Projectiles.Minions.StardustCore>();
            Item.shootSpeed = 10f;
            Item.buffType = ModContent.BuffType<Buffs.StardustCoreBuff>(); // buff (z.B. Icon oben)
            Item.autoReuse = false;
        }

        public override bool Shoot(Player player, EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
        {
            player.AddBuff(Item.buffType, 2); // Buff aktivieren, damit Minion bestehen bleibt
            Vector2 summonPosition = Main.MouseWorld;
            Projectile.NewProjectile(source, summonPosition, Vector2.Zero, type, damage, knockback, player.whoAmI);
            return false; // Kein Standard-Schuss
        }
        public override void AddRecipes()
        {
            CreateRecipe()
                .AddIngredient(ItemID.FragmentStardust, 18)
                .AddTile(TileID.LunarCraftingStation)
                .Register();
        }

                public override void ModifyTooltips(List<TooltipLine> tooltips)
        {
            tooltips.Add(new TooltipLine(Mod, "CustomTooltip", "Conjure a powerfull core of concentrated Stardust Energy"));
        }
    }
}