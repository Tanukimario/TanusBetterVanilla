using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.DataStructures;
using Microsoft.Xna.Framework;
using TanusBetterVanilla.Content.Items.Materials;
using Terraria.GameContent.ItemDropRules;
using TanusBetterVanilla.Content.Projectiles;
using System;
using System.Collections.Generic;

namespace TanusBetterVanilla.Content.Items.Weapons.Magic
{
    public class TidalWave : ModItem
    {
        public override void SetDefaults()
        {
            Item.damage = 34;
            Item.knockBack = 5f;
            Item.value = 15000;
            Item.rare = ItemRarityID.Green;
            Item.DamageType = DamageClass.Magic;
            Item.UseSound = SoundID.Item21;
            Item.mana = 8; // This item uses 8 mana
            Item.width = Item.height = 40;
            Item.scale = 1f;
            Item.useStyle = ItemUseStyleID.Shoot;
            Item.shoot = ModContent.ProjectileType<DummyProjectile>();
        }

        public override bool Shoot(Player player, EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
        {
            int chosenType = type;
            Item.useTime = 18;
            Item.useAnimation = 20;
            Item.reuseDelay = 20;
            Item.shootSpeed = 12f;
            damage = 42;
            float spread = MathHelper.ToRadians(25f); // Gesamtwinkel (optional: z.B. 25f = ~±12.5°)
            int numProjectiles = 5;
            float baseAngle = velocity.ToRotation();
            for (int i = 0; i < numProjectiles; i++)
            {
                // Lerp zwischen -Spread/2 bis +Spread/2 über alle Projektile
                float t = i / (float)(numProjectiles - 1);
                float angle = MathHelper.Lerp(-spread / 2, spread / 2, t);
                float rotatedSpeed = baseAngle + angle;
                Vector2 perturbedVelocity = new Vector2((float)Math.Cos(rotatedSpeed), (float)Math.Sin(rotatedSpeed)) * Item.shootSpeed;
                Projectile.NewProjectile(source, position, perturbedVelocity, ModContent.ProjectileType<Wave>(), damage, knockback, player.whoAmI);
            }
            Projectile.NewProjectile(source, position, velocity, chosenType, damage, knockback, player.whoAmI);
            return false; // verhindert, dass das Standard-Projektil gespawnt wird
        }
        public override void SetStaticDefaults()
        {
            Item.staff[Item.type] = true;
        }
        public override void ModifyTooltips(List<TooltipLine> tooltips)
        {
            tooltips.Add(new TooltipLine(Mod, "CustomTooltip", "Shoots magical waves to drown your enemies\n♪ Bwah nu nu nu ♫ Bwah nu nu nu ♪ wahsho"));
        }
        public override void AddRecipes()
        {
            CreateRecipe()
                .AddIngredient(ModContent.ItemType<AzueriteBar>(), 24)
                .AddIngredient(ItemID.Book, 1)
                .AddTile(TileID.Bookcases)
                .Register();
        }
    }
    public class OceanCrateLoot : GlobalItem
    {
        public override void ModifyItemLoot(Item item, ItemLoot itemLoot)
        {
            // Nur Ocean Crates (und ggf. Hardmode Ocean Crates)
            if (item.type == ItemID.OceanCrate || item.type == ItemID.OceanCrateHard)
            {
                // 1 in 6 Chance dein Item zu erhalten
                itemLoot.Add(ItemDropRule.Common(ModContent.ItemType<TidalWave>(), 6));
            }
            if (item.type == ItemID.OceanCrateHard)
            {
                itemLoot.Add(ItemDropRule.Common(ModContent.ItemType<AzueriteBar>(), 3));
            }
        }
    }
}