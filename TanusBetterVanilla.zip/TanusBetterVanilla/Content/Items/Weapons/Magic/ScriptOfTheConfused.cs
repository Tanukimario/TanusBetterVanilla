using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Microsoft.Xna.Framework;
using TanusBetterVanilla.Content.Items.Materials;
using TanusBetterVanilla.Content.Projectiles;
using System.Collections.Generic;

namespace TanusBetterVanilla.Content.Items.Weapons.Magic
{
    public class ScriptOfTheConfused : ModItem
    {
        public override void SetDefaults()
        {
            // Helper method to quickly set basic magic weapon properties
            Item.DefaultToMagicWeapon(
                projType: ModContent.ProjectileType<Nanites>(), // Our own projectile
                singleShotTime: 1, // useTime & useAnimation
                shotVelocity: 15f,
                hasAutoReuse: true
                );

            Item.damage = 50;
            Item.knockBack = 1.5f;
            Item.value = 90000;
            Item.rare = ItemRarityID.Lime;
            Item.UseSound = SoundID.Item20;
            Item.mana = 2; // This item uses 2 mana
            Item.width = Item.height = 40;
            Item.scale = 1f;
            Item.useStyle = ItemUseStyleID.Shoot;
        }

        public override void AddRecipes()
        {
            CreateRecipe()
                .AddIngredient(ItemID.Nanites, 150)
                .AddIngredient(531, 1) //Spell Tome
                .AddTile(TileID.Bookcases)
                .Register();
        }
        public override void SetStaticDefaults()
        {
            Item.staff[Item.type] = true;
        }
        public override void ModifyTooltips(List<TooltipLine> tooltips)
        {
            tooltips.Add(new TooltipLine(Mod, "CustomTooltip", "Fires a neverending stream on Nanites"));
        }
    }
}