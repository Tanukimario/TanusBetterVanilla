using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.DataStructures;
using Microsoft.Xna.Framework;
using TanusBetterVanilla.Content.Items.Materials;
using Terraria.GameContent.ItemDropRules;
using TanusBetterVanilla.Content.Projectiles;
using System;
using System.Collections.Generic;

//Friedolin = Fantastic, Real, Interesting, Exiting, Devious, Overpowered, Lovely, Illustrious Nuke

namespace TanusBetterVanilla.Content.Items.Weapons.Magic
{
    public class Friedolin : ModItem
    {
        private int projectileIndex = 0; //rot=0, orange=1, gelb=2, grün=3, hellblau=4, blau=5, lila=6, pink=7
        private readonly int[] projectileCycle = new int[]
        {
        ModContent.ProjectileType<Friedolin0>(),
        ModContent.ProjectileType<Friedolin1>(),
        ModContent.ProjectileType<Friedolin2>(),
        ModContent.ProjectileType<Friedolin3>(),
        ModContent.ProjectileType<Friedolin4>(),
        ModContent.ProjectileType<Friedolin5>(),
        ModContent.ProjectileType<Friedolin6>(),
        ModContent.ProjectileType<Friedolin7>(),
        };
        public override void SetDefaults()
        {
            Item.damage = 420;
            Item.crit = 42;
            Item.knockBack = 5f;
            Item.useTime = 5;
            Item.useAnimation = 5;
            Item.shootSpeed = 15f;
            Item.value = 15000;
            Item.DamageType = DamageClass.Magic;
            Item.rare = ItemRarityID.Red;
            Item.UseSound = SoundID.Item91;
            Item.mana = 8; // This item uses 8 mana
            Item.width = Item.height = 40;
            Item.scale = 1f;
            Item.useStyle = ItemUseStyleID.Shoot;
            Item.shoot = ModContent.ProjectileType<DummyProjectile>();
        }

        public override bool Shoot(Player player, EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
        {
            Vector2 direction = Main.MouseWorld - position;
            direction.Normalize();
            direction *= Item.shootSpeed;

            int projType = projectileCycle[projectileIndex];

            Projectile.NewProjectile(source, position, direction, projType, damage, knockback, player.whoAmI);

            projectileIndex = (projectileIndex + 1) % projectileCycle.Length;

            return false; // Weil wir das Projektil manuell gespawnt haben
        }
        public override void SetStaticDefaults()
        {
            Item.staff[Item.type] = true;
        }
        public override void ModifyTooltips(List<TooltipLine> tooltips)
        {
            tooltips.Add(new TooltipLine(Mod, "CustomTooltip", "Anihilate your foes with a flurry of Cromatic Rays\n'Ich bin Hart'"));
        }
        public override void AddRecipes()
        {
            CreateRecipe()
                .AddIngredient(3467, 5)
                .AddIngredient(1066, 1)
                .AddIngredient(1724, 1)
                .AddIngredient(2676, 5)
                .AddTile(TileID.LunarCraftingStation)
                .Register();
        }
    }
}