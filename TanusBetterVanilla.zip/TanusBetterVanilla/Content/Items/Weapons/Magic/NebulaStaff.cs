using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Microsoft.Xna.Framework;
using TanusBetterVanilla.Content.Items.Materials;
using TanusBetterVanilla.Content.Projectiles;
using System.Collections.Generic;

namespace TanusBetterVanilla.Content.Items.Weapons.Magic
{
    public class NebulaStaff : ModItem
    {
        public override void SetDefaults()
        {
            // Helper method to quickly set basic magic weapon properties
            Item.DefaultToMagicWeapon(
                projType: ModContent.ProjectileType<NebulaRay>(), // Our own projectile
                singleShotTime: 35, // useTime & useAnimation
                shotVelocity: 20f,
                hasAutoReuse: true
                );

            Item.damage = 75;
            Item.knockBack = 1.5f;
            Item.value = 100000;
            Item.rare = ItemRarityID.Red;
            Item.UseSound = SoundID.Item20;
            Item.mana = 10;
            Item.width = Item.height = 40;
            Item.scale = 1.25f;
            Item.useStyle = ItemUseStyleID.Shoot;
        }

        public override void AddRecipes()
        {
            CreateRecipe()
                .AddIngredient(ItemID.FragmentNebula, 18)
                .AddTile(TileID.LunarCraftingStation)
                .Register();
        }
        public override void SetStaticDefaults()
        {
            Item.staff[Item.type] = true;
        }
        public override void ModifyTooltips(List<TooltipLine> tooltips)
        {
            tooltips.Add(new TooltipLine(Mod, "CustomTooltip", "Focus a ray of pure cosmic energy on your enemies"));
        }
    }
}