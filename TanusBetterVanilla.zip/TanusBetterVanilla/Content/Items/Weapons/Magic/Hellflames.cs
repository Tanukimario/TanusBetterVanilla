using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Microsoft.Xna.Framework;
using TanusBetterVanilla.Content.Items.Materials;
using TanusBetterVanilla.Content.Projectiles;
using System.Collections.Generic;

namespace TanusBetterVanilla.Content.Items.Weapons.Magic
{
    public class Hellflames : ModItem
    {
        public override void SetDefaults()
        {
            // Helper method to quickly set basic magic weapon properties
            Item.DefaultToMagicWeapon(
                projType: ModContent.ProjectileType<Hellflame>(), // Our own projectile
                singleShotTime: 35, // useTime & useAnimation
                shotVelocity: 9f,
                hasAutoReuse: true
                );

            Item.damage = 54;
            Item.knockBack = 15f;
            Item.value = 6000;
            Item.rare = ItemRarityID.Orange;
            Item.UseSound = SoundID.Item20;
            Item.mana = 8; // This item uses 8 mana
            Item.width = Item.height = 40;
            Item.scale = 1f;
            Item.useStyle = ItemUseStyleID.Shoot;
        }

        public override void AddRecipes()
        {
            CreateRecipe()
                .AddIngredient(ItemID.HellstoneBar, 20)
                .AddIngredient(ItemID.Book, 1)
                .AddTile(TileID.Bookcases)
                .Register();
        }
        public override void SetStaticDefaults()
        {
            Item.staff[Item.type] = true;
        }

        public override void ModifyTooltips(List<TooltipLine> tooltips)
        {
            tooltips.Add(new TooltipLine(Mod, "CustomTooltip", "Shoots an explosive fireball to incinerate your foes"));
        }
    }
}

