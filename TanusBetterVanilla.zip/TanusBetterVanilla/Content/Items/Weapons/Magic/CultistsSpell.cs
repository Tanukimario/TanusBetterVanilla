using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.DataStructures;
using Microsoft.Xna.Framework;
using TanusBetterVanilla.Content.Items.Materials;
using TanusBetterVanilla.Content.Projectiles;
using System;
using System.Collections.Generic;

namespace TanusBetterVanilla.Content.Items.Weapons.Magic
{
    public class CultistsSpell : ModItem
    {
        private int mode = 0; // 0=Solar, 1=Vortex, 2=Nebula, 3=Stardust

        protected override bool CloneNewInstances => true;

        public override void SetStaticDefaults()
        {
            Item.staff[Item.type] = true;
        }

        public override void SetDefaults()
        {
            Item.damage = 0;
            Item.knockBack = 1.5f;
            Item.value = 150000;
            Item.rare = ItemRarityID.Red;
            Item.UseSound = SoundID.Item20;
            Item.mana = 10;
            Item.width = Item.height = 40;
            Item.scale = 1f;
            Item.useTime = 6;
            Item.useAnimation = 6;
            Item.useStyle = ItemUseStyleID.Shoot;
            Item.noMelee = true;
            Item.autoReuse = true;
            Item.shootSpeed = 15f;
            Item.DamageType = DamageClass.Magic;
            Item.shoot = ModContent.ProjectileType<DummyProjectile>();
        }

        public override bool AltFunctionUse(Player player)
        {
            return true; // Rechtsklick erlauben
        }

        public override bool CanUseItem(Player player)
        {
            if (player.altFunctionUse == 2) // Rechtsklick
            {
                if (Main.myPlayer == player.whoAmI)
                {
                    mode = (mode + 1) % 4;

                    // Feedback im Chat
                    string msg = mode switch
                    {
                        0 => "Changed to Solar Spell",
                        1 => "Changed to Vortex Spell",
                        2 => "Changed to Nebula Spell",
                        3 => "Changed to Stardust Spell",
                        _ => "Unknown Mode"
                    };

                    Color color = mode switch
                    {
                        0 => new Color(237, 111, 47),
                        1 => new Color(54, 186, 147),
                        2 => new Color(171, 85, 181),
                        3 => new Color(103, 202, 224),
                        _ => Color.White
                    };

                    Main.NewText(msg, color);
                }

                return false; // keine Aktion beim Rechtsklick außer Moduswechsel
            }

            return true; // Linksklick erlaubt
        }

        public override bool Shoot(Player player, EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
        {
            int chosenType = type;
            switch (mode)
            {
                case 0:
                    damage = 96;
                    Item.useTime = 6;
                    Item.useAnimation = 24;
                    Item.shootSpeed = 15f;
                    Item.reuseDelay = 25;
                    chosenType = ModContent.ProjectileType<CultistFlare>(); // Solar
                    break;
                case 1:
                    damage = 57;
                    Item.useTime = 5;
                    Item.useAnimation = 15;
                    Item.shootSpeed = 15f;
                    Item.reuseDelay = 20;
                    chosenType = ModContent.ProjectileType<VortexBolt>(); // Vortex
                    break;
                case 2:
                    damage = 73;
                    Item.useTime = 5;
                    Item.useAnimation = 15;
                    Item.shootSpeed = 2.5f;
                    Item.reuseDelay = 30;
                    chosenType = ModContent.ProjectileType<CultistVoid>(); // Nebula
                    break;
                case 3:
                    Item.useTime = 18;
                    Item.useAnimation = 20;
                    Item.reuseDelay = 20;
                    Item.shootSpeed = 12f;
                    damage = 42;
                    float spread = MathHelper.ToRadians(25f); // Gesamtwinkel (optional: z.B. 25f = ~±12.5°)
                    int numProjectiles = 5;
                    float baseAngle = velocity.ToRotation();
                    for (int i = 0; i < numProjectiles; i++)
                    {
                        // Lerp zwischen -Spread/2 bis +Spread/2 über alle Projektile
                        float t = i / (float)(numProjectiles - 1);
                        float angle = MathHelper.Lerp(-spread / 2, spread / 2, t);
                        float rotatedSpeed = baseAngle + angle;
                        Vector2 perturbedVelocity = new Vector2((float)Math.Cos(rotatedSpeed), (float)Math.Sin(rotatedSpeed)) * Item.shootSpeed;
                        Projectile.NewProjectile(source, position, perturbedVelocity, ModContent.ProjectileType<CultistStar>(), damage, knockback, player.whoAmI);
                    }
                    break;
            }

            Projectile.NewProjectile(source, position, velocity, chosenType, damage, knockback, player.whoAmI);
            return false; // verhindert, dass das Standard-Projektil gespawnt wird
        }

        public override void AddRecipes()
        {
            CreateRecipe()
                .AddIngredient(ItemID.FragmentSolar, 6)
                .AddIngredient(ItemID.FragmentVortex, 6)
                .AddIngredient(ItemID.FragmentNebula, 6)
                .AddIngredient(ItemID.FragmentStardust, 6)
                .AddIngredient(ItemID.SpellTome, 1)
                .AddTile(TileID.LunarCraftingStation)
                .Register();
        }

        public override void ModifyTooltips(List<TooltipLine> tooltips)
        {
            tooltips.Add(new TooltipLine(Mod, "CustomTooltip", "Casts 1 of 4 Ancient Spells\nRight Click to Change Mode"));
        }
    }

    public class MyGlobalNPC : GlobalNPC
    {
        public override void OnKill(NPC npc)
        {
            // Beispiel: Die Waffe soll vom Skeletron (Boss) mit 20% fallen gelassen werden
            if (npc.type == 439 && Main.rand.NextFloat() < 0.33f)
            {
                // Ersetze MyWeapon durch den Typ deiner Waffe
                Item.NewItem(npc.GetSource_Loot(), npc.getRect(), ModContent.ItemType<CultistsSpell>());
            }
        }
    }
}