using TanusBetterVanilla.Content.Projectiles; // Using our Materials folder
using Terraria;
using Terraria.GameContent.Creative;
using Terraria.ID;
using Terraria.ModLoader;
using Microsoft.Xna.Framework;
using Terraria.DataStructures;
using Terraria.Audio;
using System;
using System.Collections.Generic;

namespace TanusBetterVanilla.Content.Items.Weapons.Melee
{
    public class PocketSun : ModItem
    {
        public override void SetStaticDefaults()
        {
            ItemID.Sets.Yoyo[Item.type] = true; // Markiert es als Yoyo
        }

        public override void SetDefaults()
        {
            Item.damage = 120;
            Item.DamageType = DamageClass.Melee;
            Item.width = 32;
            Item.height = 32;
            Item.useTime = 25;
            Item.useAnimation = 25;
            Item.useStyle = ItemUseStyleID.Shoot;
            Item.noMelee = true; // Macht keinen direkten Nahkampfschaden
            Item.knockBack = 2f;
            Item.value = Item.buyPrice(gold: 1);
            Item.rare = ItemRarityID.Red;
            Item.UseSound = SoundID.Item1;
            Item.autoReuse = true;
            Item.channel = true; // Damit man das Yoyo gedrückt halten kann
            Item.noUseGraphic = true;
            Item.shoot = ModContent.ProjectileType<PocketSunProjectile>(); // Dein Projektil
            Item.shootSpeed = 48f; // Yoyo-Reichweite
        }

        public override void AddRecipes()
        {
            CreateRecipe()
                .AddIngredient(ItemID.FragmentSolar, 18)
                .AddTile(TileID.LunarCraftingStation)
                .Register();
        }

        public override void ModifyTooltips(List<TooltipLine> tooltips)
        {
            tooltips.Add(new TooltipLine(Mod, "CustomTooltip", "Crush your enemies with your very of Sun\n'Is that a sun in your pocket or are you just exited to se me?'"));
        }
    }
}