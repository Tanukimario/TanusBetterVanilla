using TanusBetterVanilla.Content.Items.Materials; // Using our Materials folder
using TanusBetterVanilla.Content.Projectiles; // Using our Materials folder
using Terraria;
using Terraria.GameContent.Creative;
using Terraria.ID;
using Terraria.ModLoader;
using Microsoft.Xna.Framework;

namespace TanusBetterVanilla.Content.Items.Weapons.Melee // Where is your code locates
{
    public class AzueriteBroadsword : ModItem
    {
        public override void SetStaticDefaults()
        {
            CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[Type] = 1; // How many items need for research in Journey Mode
        }

        public override void SetDefaults()
        {
            // Visual properties
            Item.width = 32; // Width of an item sprite
            Item.height = 32; // Height of an item sprite
            Item.scale = 1f; // Multiplicator of item size, for example is you set this to 2f our sword will be biger twice. IMPORTANT: If you are using numbers with floating point, write "f" in their end, like 1.5f, 3.14f, 2.1278495f etc.
            Item.rare = ItemRarityID.Orange; // The color of item's name in game. Check https://terraria.wiki.gg/wiki/Rarity

            // Combat properties
            Item.damage = 32; // Item damage
            Item.DamageType = DamageClass.Melee; // What type of damage item is deals, Melee, Ranged, Magic, Summon, Generic (takes bonuses from all damage multipliers), Default (doesn't take bonuses from any damage multipliers)
            // useTime and useAnimation often use the same value, but we'll see examples where they don't use the same values
            Item.useTime = 18; // How long the swing lasts in ticks (60 ticks = 1 second)
            Item.useAnimation = 18; // How long the swing animation lasts in ticks (60 ticks = 1 second)
            Item.knockBack = 7f; // How far the sword punches enemies, 20 is maximal value
            Item.autoReuse = true; // Can the item auto swing by holding the attack button

            // Other properties
            Item.value = 50000; // Item sell price in copper coins
            Item.useStyle = ItemUseStyleID.Swing; // This is how you're holding the weapon, visit https://terraria.wiki.gg/wiki/Use_Style_IDs for list of possible use styles
            Item.UseSound = SoundID.Item1; // What sound is played when using the item, all sounds can be found here - https://terraria.wiki.gg/wiki/Sound_IDs
        }

        // Creating item craft
        public override void AddRecipes()
        {
            Recipe recipe = CreateRecipe();
            recipe.AddIngredient(ModContent.ItemType<AzueriteBar>(), 16); // Use ModContent.ItemType
            recipe.AddTile(TileID.Anvils);
            recipe.Register();
        }

        public override void MeleeEffects(Player player, Rectangle hitbox)
        {
            if (Main.rand.NextBool(3)) // With 1/3 chance per tick (60 ticks = 1 second)...
            {
                // ...spawning dust
                Dust.NewDust(new Vector2(hitbox.X, hitbox.Y), // Position to spawn
                hitbox.Width, hitbox.Height, // Width and Height
                DustID.Water, // Dust type. Check https://terraria.wiki.gg/wiki/Dust_IDs
                0, 0, // Speed X and Speed Y of dust, it have some randomization
                125
                ); // Dust transparency, 0 - full visibility, 255 - full transparency

            }
        }

        public override void OnHitNPC(Player player, NPC target, NPC.HitInfo hit, int damageDone)
        {
            Projectile.NewProjectile(
                target.GetSource_OnHit(target),
                target.Center,
                new Vector2(0, -5f),
                ModContent.ProjectileType<AzureSplash>(),
                20,
                1f,
                player.whoAmI
            );
        }
    }
}