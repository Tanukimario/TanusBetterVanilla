using TanusBetterVanilla.Content.Projectiles; // Using our Materials folder
using Terraria;
using Terraria.GameContent.Creative;
using Terraria.ID;
using Terraria.ModLoader;
using Microsoft.Xna.Framework;
using Terraria.DataStructures;
using Terraria.Audio;
using System;
using System.Collections.Generic;

namespace TanusBetterVanilla.Content.Items.Weapons.Melee // Where is your code locates
{
    public class BalefullHarvest : ModItem
    {
        public override void SetStaticDefaults()
        {
            CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[Type] = 1; // How many items need for research in Journey Mode
        }

        public override void SetDefaults()
        {
            // Visual properties
            Item.width = 32;
            Item.height = 32;
            Item.scale = 1.75f;
            Item.rare = ItemRarityID.Lime;

            // Combat properties
            Item.damage = 69;
            Item.DamageType = DamageClass.Melee;
            Item.useTime = 20;
            Item.useAnimation = 20;
            Item.knockBack = 6f;
            Item.autoReuse = true;
            Item.shoot = ModContent.ProjectileType<BalefullScythe>(); // Dein Projektil
            Item.shootSpeed = 10f;

            // Other properties
            Item.value = 90000;
            Item.useStyle = ItemUseStyleID.Swing;
            Item.UseSound = SoundID.Item1;
        }

        // Creating item craft
        public override void AddRecipes()
        {
            CreateRecipe()
            .AddIngredient(ModContent.ItemType<Shadescythe>(), 1)
            .AddIngredient(1327, 1) //Death Sickle
            .AddIngredient(1508, 10) //Ectoplasm
            .AddIngredient(1725, 25) //Pumpkin
            .AddTile(TileID.MythrilAnvil)
            .Register();

            CreateRecipe()
            .AddIngredient(ModContent.ItemType<Bloodscythe>(), 1)
            .AddIngredient(1327, 1) //Death Sickle
            .AddIngredient(1508, 10) //Ectoplasm
            .AddIngredient(1725, 25) //Pumpkin
            .AddTile(TileID.MythrilAnvil)
            .Register();
        }

        public override void MeleeEffects(Player player, Rectangle hitbox)
        {
            if (Main.rand.NextBool(3)) // With 1/3 chance per tick (60 ticks = 1 second)...
            {
                // ...spawning dust
                Dust.NewDust(new Vector2(hitbox.X, hitbox.Y), // Position to spawn
                hitbox.Width, hitbox.Height, // Width and Height
                DustID.DesertPot, // Dust type. Check https://terraria.wiki.gg/wiki/Dust_IDs
                0, 0, // Speed X and Speed Y of dust, it have some randomization
                125); // Dust transparency, 0 - full visibility, 255 - full transparency

            }
        }
        public override void OnHitNPC(Player player, NPC target, NPC.HitInfo hit, int damageDone)
        {
            Projectile.NewProjectile(
                target.GetSource_OnHit(target),
                target.Center,
                new Vector2(0, -5f),
                ModContent.ProjectileType<PumpkinHarvest>(),
                20,
                1f,
                player.whoAmI
            );
        }

                public override void ModifyTooltips(List<TooltipLine> tooltips)
        {
            tooltips.Add(new TooltipLine(Mod, "CustomTooltip", "Shoots phantasmal scythes."));
        }
    }
}