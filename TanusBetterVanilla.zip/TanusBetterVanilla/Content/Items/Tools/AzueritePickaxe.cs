using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using TanusBetterVanilla.Content.Items.Materials;

namespace TanusBetterVanilla.Content.Items.Tools
{
    public class AzueritePickaxe : ModItem
    {
        public override void SetDefaults()
        {
            Item.damage = 11;
            Item.DamageType = DamageClass.Melee;
            Item.width = 40;
            Item.height = 40;
            Item.useTime = 10;
            Item.useAnimation = 15;
            Item.useStyle = ItemUseStyleID.Swing;
            Item.knockBack = 2f;
            Item.value = Item.sellPrice(silver: 50);
            Item.rare = ItemRarityID.Orange;
            Item.UseSound = SoundID.Item1;
            Item.autoReuse = true;
            
            Item.pick = 100;

            Item.useTurn = true;
        }

        public override void AddRecipes()
        {
            Recipe recipe = CreateRecipe();
            recipe.AddIngredient(ModContent.ItemType<AzueriteBar>(), 19);
            recipe.AddTile(TileID.Anvils);
            recipe.Register();
        }
    }
}