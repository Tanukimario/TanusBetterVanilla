﻿using Terraria;
using Terraria.ID;
using Terraria.Localization;
using Terraria.ModLoader;
using TanusBetterVanilla.Content.Items.Armor;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;

namespace TanusBetterVanilla.Content.Items.Armor
{
	// The AutoloadEquip attribute automatically attaches an equip texture to this item.
	// Providing the EquipType.Head value here will result in TML expecting a X_Head.png file to be placed next to the item's main texture.
	[AutoloadEquip(EquipType.Head)]
	public class LuminiteHood : ModItem
	{
		public static readonly int AdditiveGenericDamageBonus = -50;

		public static LocalizedText SetBonusText { get; private set; }

		public override void SetDefaults()
		{
			Item.width = 18; // Width of the item
			Item.height = 18; // Height of the item
			Item.value = Item.sellPrice(gold: 1); // How many coins the item is worth
			Item.rare = ItemRarityID.Red; // The rarity of the item
			Item.defense = 7; // The amount of defense the item will give when equipped
		}

		// IsArmorSet determines what armor pieces are needed for the setbonus to take effect
		public override bool IsArmorSet(Item head, Item body, Item legs)
		{
			return body.type == ModContent.ItemType<LuminiteBreastplate>() && legs.type == ModContent.ItemType<LuminiteGreaves>();
		}

		public override void ModifyTooltips(List<TooltipLine> tooltips)
        {
            tooltips.Add(new TooltipLine(Mod, "CustomTooltip", "Increases block placement range by 2\n15% increased mining speed"));
        }

		// UpdateArmorSet allows you to give set bonuses to the armor.
		public override void UpdateArmorSet(Player player)
		{
			player.setBonus = "All damage is severly reduced"; // This is the setbonus tooltip: "Increases dealt damage by 20%"
			player.GetDamage(DamageClass.Generic) += AdditiveGenericDamageBonus / 100f; // Increase dealt damage for all weapon classes by 20%
			player.GetModPlayer<LuminiteBonusPlayer>().reduceDamageTaken = true;
		}
		public override void UpdateEquip(Player player)
		{
			player.blockRange += 2;
			player.pickSpeed -= 0.15f;
			Lighting.AddLight(player.Center, new Vector3(0.0f, 1.0f, 1.0f));
		}
		public override void AddRecipes()
        {
            CreateRecipe()
                .AddIngredient(4008, 1) //Ultrabright Helmet
                .AddIngredient(3467, 8) //Luminite Bar
                .AddTile(TileID.LunarCraftingStation)
                .Register();
        }
	}
}
