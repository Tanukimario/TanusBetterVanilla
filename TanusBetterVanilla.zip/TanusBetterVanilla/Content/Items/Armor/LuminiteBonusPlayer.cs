using Terraria;
using Terraria.ModLoader;

namespace TanusBetterVanilla.Content.Items.Armor
{
    public class LuminiteBonusPlayer : ModPlayer
    {
        public bool reduceDamageTaken = false;

        public override void ResetEffects()
        {
            reduceDamageTaken = false;
        }

        public override void ModifyHurt(ref Player.HurtModifiers modifiers)
        {
            if (reduceDamageTaken)
            {
                modifiers.FinalDamage *= 0.5f; // 50% weniger Schaden
            }
        }
    }
}