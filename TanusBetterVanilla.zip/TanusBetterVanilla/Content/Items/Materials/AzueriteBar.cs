using TanusBetterVanilla.Content.Items.Materials; // Using our Materials folder
using Terraria;
using Terraria.GameContent.Creative;
using Terraria.ID;
using Terraria.ModLoader;
using Microsoft.Xna.Framework;
using TanusBetterVanilla.Content.Items.Tiles;
using TanusBetterVanilla.Content.Tiles.Blocks;

namespace TanusBetterVanilla.Content.Items.Materials // Where your code is located
{
    public class AzueriteBar : ModItem // Your item name (TestMaterial) and type (ModItem)
    {
        public override void SetStaticDefaults()
        {
            CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[Type] = 100; // How many items need for research in Journey Mode
        }

        public override void SetDefaults()
        {
            Item.width = 32; // Width of an item sprite
            Item.height = 32; // Height of an item sprite
            Item.maxStack = 9999; // How many items can be in one inventory slot
            Item.value = 100; // Item sell price in copper coins
            Item.rare = ItemRarityID.Blue; // The color of item's name in game. Check https://terraria.wiki.gg/wiki/Rarity
            Item.useStyle = ItemUseStyleID.Swing;
            Item.useTime = 10;
            Item.useAnimation = 15;
            Item.consumable = false;
        }

        public override void AddRecipes()
        {
            Recipe recipe = CreateRecipe();
            recipe.AddIngredient(ModContent.ItemType<ShimmeringSand>(), 2); // Use ModContent.ItemType
            recipe.AddTile(TileID.Furnaces);
            recipe.Register();
        }
    }
}