// What libraries we use in the code
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.Localization;
using Terraria.GameContent.Creative;

namespace TanusBetterVanilla.Content.Items.Materials // Where your code is located
{
    public class TestMaterial : ModItem // Your item name (TestMaterial) and type (ModItem)
    {
        public override void SetStaticDefaults()
        {
            CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[Type] = 100; // How many items need for research in Journey Mode
        }

        public override void SetDefaults()
        {
            Item.width = 32; // Width of an item sprite
            Item.height = 32; // Height of an item sprite
            Item.maxStack = 9999; // How many items can be in one inventory slot
            Item.value = 100; // Item sell price in copper coins
            Item.rare = ItemRarityID.Blue; // The color of item's name in game. Check https://terraria.wiki.gg/wiki/Rarity
        }
    }
}

