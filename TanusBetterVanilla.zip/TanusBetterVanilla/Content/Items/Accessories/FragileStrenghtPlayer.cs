using Terraria;
using Terraria.ModLoader;

namespace TanusBetterVanilla.Content.Items.Accessories
{
    public class FragileStrenghtPlayer : ModPlayer
    {
        public bool takesExtraDamage;

        public override void ResetEffects()
        {
            takesExtraDamage = false; // Effekt pro Tick zurücksetzen
        }

        public override void ModifyHitByNPC(NPC npc, ref Player.HurtModifiers modifiers)
        {
            if (takesExtraDamage)
            {
                modifiers.FinalDamage *= 1.5f;
            }
        }

        public override void ModifyHitByProjectile(Projectile proj, ref Player.HurtModifiers modifiers)
        {
            if (takesExtraDamage)
            {
                modifiers.FinalDamage *= 1.5f;
            }
        }
    }
}