using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using System;
using System.Collections.Generic;

namespace TanusBetterVanilla.Content.Items.Accessories
{
    public class FragileStrenght : ModItem
    {
        public override void ModifyTooltips(List<TooltipLine> tooltips)
        {
            tooltips.Add(new TooltipLine(Mod, "CustomTooltip", "Strenghthens the bearer, increasing the damage they deal to enemies with their weapon\nThis accessorie is fragile, and so is its bearer"));
        }

        public override void SetDefaults()
        {
            Item.width = 28;
            Item.height = 28;
            Item.value = Item.sellPrice(gold: 10);
            Item.rare = ItemRarityID.LightRed;
            Item.accessory = true;
        }

        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            player.GetDamage(DamageClass.Melee) += 0.5f;
            player.GetDamage(DamageClass.Ranged) += 0.5f;
            player.GetDamage(DamageClass.Magic) += 0.5f;
            player.GetDamage(DamageClass.Throwing) += 0.5f;
            player.GetDamage(DamageClass.Summon) += 0.5f;
            player.GetDamage(DamageClass.Generic) += 0.5f;

            player.GetModPlayer<FragileStrenghtPlayer>().takesExtraDamage = true;
        }

        public override void AddRecipes()
        {
            CreateRecipe()
                .AddIngredient(ItemID.Glass, 10)
                .AddIngredient(ItemID.CrystalShard, 12)
                .AddIngredient(74, 1) //Platinum Coin
                .AddTile(TileID.MythrilAnvil)
                .Register();
        }
    }
}