using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using System;
using System.Collections.Generic;

namespace TanusBetterVanilla.Content.Items.Accessories
{
    public class HeartOfTheMechs : ModItem
    {
        public override void ModifyTooltips(List<TooltipLine> tooltips)
        {
            tooltips.Add(new TooltipLine(Mod, "CustomTooltip", "6 Defencs\nIncreases most stats significantly"));
        }
        public override void SetDefaults()
        {
            Item.width = 28;
            Item.height = 28;
            Item.accessory = true;
            Item.value = Item.sellPrice(gold: 5);
            Item.rare = ItemRarityID.LightPurple;
        }

        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            player.GetDamage(DamageClass.Generic) += 0.17f; //+15% Schaden
            player.GetCritChance(DamageClass.Generic) += 10; //+8 crit chance
            player.GetAttackSpeed(DamageClass.Generic) += 0.15f; //+15% angriffgeschwindigkeit
            player.pickSpeed -= 0.15f;
            player.statLifeMax2 += 30; // Max HP +30
            player.statDefense += 6; // Defence +5
            player.lifeRegen += 3; // Life Regen +2hp/s  
            player.maxRunSpeed += 2; // +4 kmh max speed
            player.jumpSpeedBoost += 5; // +4 blöcke sprunghöhe
            player.wingTimeMax += 3; // +2s flight time
        }

        public override void AddRecipes()
        {
            CreateRecipe()
                .AddIngredient(ModContent.ItemType<MechanicalEngineParts>(), 1)
                .AddIngredient(ModContent.ItemType<OffensiveMechParts>(), 1)
                .AddIngredient(ModContent.ItemType<VitalMechParts>(), 1)
                .AddIngredient(ItemID.HallowedBar, 15)
                .AddIngredient(549, 12) //Soul of Sight
                .AddIngredient(548, 12) //Soul of Might
                .AddIngredient(547, 12) //Soul of Fright
                .AddTile(TileID.MythrilAnvil)
                .Register();
        }
    }
}