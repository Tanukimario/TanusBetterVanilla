using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using System;
using System.Collections.Generic;

namespace TanusBetterVanilla.Content.Items.Accessories
{
    public class VitalMechParts : ModItem
    {
        public override void ModifyTooltips(List<TooltipLine> tooltips)
        {
            tooltips.Add(new TooltipLine(Mod, "CustomTooltip", "5 defense\nIncreases maximum life by 30\nIncreases life regeneration by 2hp/s"));
        }
        public override void SetDefaults()
        {
            Item.width = 28;
            Item.height = 28;
            Item.accessory = true;
            Item.value = Item.sellPrice(gold: 5);
            Item.rare = ItemRarityID.Pink;
        }

        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            player.statLifeMax2 += 30; // Max HP +30
            player.statDefense += 5; // Defence +5
            player.lifeRegen += 2; // Life Regen +2hp/s
            player.GetDamage(DamageClass.Generic) -= 0.5f;
        }
    }
}