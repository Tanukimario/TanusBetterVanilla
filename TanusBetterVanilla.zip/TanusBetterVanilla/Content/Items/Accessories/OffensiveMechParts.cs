using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using System;
using System.Collections.Generic;

namespace TanusBetterVanilla.Content.Items.Accessories
{
    public class OffensiveMechParts : ModItem
    {
        public override void ModifyTooltips(List<TooltipLine> tooltips)
        {
            tooltips.Add(new TooltipLine(Mod, "CustomTooltip", "15% increased damage\n8% increased crit chance\n15% increased attack speed"));
        }
        public override void SetDefaults()
        {
            Item.width = 28;
            Item.height = 28;
            Item.accessory = true;
            Item.value = Item.sellPrice(gold: 5);
            Item.rare = ItemRarityID.Pink;
        }

        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            player.GetDamage(DamageClass.Generic) += 0.15f; //+15% Schaden
            player.GetCritChance(DamageClass.Generic) += 8; //+8 crit chance
            player.GetAttackSpeed(DamageClass.Generic) += 0.15f; //+15% angriffgeschwindigkeit
            player.pickSpeed -= 0.1f;           
        }
    }
}