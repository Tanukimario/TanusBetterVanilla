using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using System;
using System.Collections.Generic;

namespace TanusBetterVanilla.Content.Items.Accessories
{
    public class UnbreakableStrenght : ModItem
    {
        public override void ModifyTooltips(List<TooltipLine> tooltips)
        {
            tooltips.Add(new TooltipLine(Mod, "CustomTooltip", "Strenghthens the bearer, increasing the damage they deal to enemies with their weapon\nThis accessorie is resilient, and so is its bearer"));
        }

        public override void SetDefaults()
        {
            Item.width = 28;
            Item.height = 28;
            Item.value = Item.sellPrice(gold: 10);
            Item.rare = ItemRarityID.LightRed;
            Item.accessory = true;
        }

        public override void SetStaticDefaults()
        {
            if (NPC.downedMoonlord == true)
            {
                ItemID.Sets.ShimmerTransformToItem[ModContent.ItemType<FragileStrenght>()] = ModContent.ItemType<UnbreakableStrenght>();
            }
        }

        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            player.GetDamage(DamageClass.Melee) += 0.5f;
            player.GetDamage(DamageClass.Ranged) += 0.5f;
            player.GetDamage(DamageClass.Magic) += 0.5f;
            player.GetDamage(DamageClass.Throwing) += 0.5f;
            player.GetDamage(DamageClass.Summon) += 0.5f;
            player.GetDamage(DamageClass.Generic) += 0.5f;
        }

        public override void AddRecipes()
        {
            CreateRecipe()
                .AddIngredient(ModContent.ItemType<FragileStrenght>(), 1)
                .AddIngredient(3460, 15) //Luminite Ore
                .AddTile(26)
                .Register();
        }
    }
}