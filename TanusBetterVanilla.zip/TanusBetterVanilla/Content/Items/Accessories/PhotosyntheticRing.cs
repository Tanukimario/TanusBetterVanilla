using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using System;
using System.Collections.Generic;

namespace TanusBetterVanilla.Content.Items.Accessories
{
    public class PhotosyntheticRing : ModItem
    {
        public override void ModifyTooltips(List<TooltipLine> tooltips)
        {
            tooltips.Add(new TooltipLine(Mod, "CustomTooltip", "Increases maximum life by 50\nIncreases life regen and movement speed during the day"));
        }
        public override void SetDefaults()
        {
            Item.width = 28;
            Item.height = 28;
            Item.accessory = true;
            Item.value = Item.sellPrice(gold: 5);
            Item.rare = ItemRarityID.Pink;
        }

        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            player.statLifeMax2 += 50; // Max HP um 50 erhöhen
            if (Main.dayTime && player.ZoneOverworldHeight)
            {
                player.moveSpeed += 0.15f; // +15% Bewegungsgeschwindigkeit
                player.lifeRegen += 3; // Regeneration
            }
        }

        public override void AddRecipes()
        {
            CreateRecipe()
                .AddIngredient(ModContent.ItemType<VitalBracelet>(), 1)
                .AddIngredient(ItemID.ChlorophyteBar, 14)
                .AddIngredient(ItemID.LifeFruit, 3)
                .AddTile(TileID.MythrilAnvil)
                .Register();
        }
    }
}