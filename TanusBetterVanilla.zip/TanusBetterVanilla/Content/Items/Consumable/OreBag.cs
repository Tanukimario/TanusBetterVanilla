using Terraria;
using Terraria.GameContent.ItemDropRules;
using Terraria.ID;
using Terraria.ModLoader;
using System;
using System.Collections.Generic;

namespace TanusBetterVanilla.Content.Items.Consumable
{
    // Basic code for a fishing crate
    // The catch code is in a separate ModPlayer class (ExampleFishingPlayer)
    // The placed tile is in a separate ModTile class
    public class OreBag : ModItem
    {
        public override void SetStaticDefaults()
        {
            // Disclaimer for both of these sets (as per their docs): They are only checked for vanilla item IDs, but for cross-mod purposes it would be helpful to set them for modded crates too
            ItemID.Sets.IsFishingCrate[Type] = true;
            //ItemID.Sets.IsFishingCrateHardmode[Type] = true; // This is a crate that mimics a pre-hardmode biome crate, so this is commented out

            Item.ResearchUnlockCount = 10;
        }

        public override void ModifyTooltips(List<TooltipLine> tooltips)
        {
            tooltips.Add(new TooltipLine(Mod, "CustomTooltip", "Right click to open"));
        }

        public override void SetDefaults()
        {
            Item.width = 12; // The hitbox dimensions are intentionally smaller so that it looks nicer when fished up on a bobber
            Item.height = 12;
            Item.rare = ItemRarityID.Orange;
            Item.value = Item.sellPrice(0, 2);
        }

        public override void ModifyResearchSorting(ref ContentSamples.CreativeHelper.ItemGroup itemGroup)
        {
            itemGroup = ContentSamples.CreativeHelper.ItemGroup.Crates;
        }

        public override bool CanRightClick()
        {
            return true;
        }

        public override void ModifyItemLoot(ItemLoot itemLoot)
        {
            IItemDropRule[] oreTypes = [
                ItemDropRule.Common(ItemID.CopperOre, 1, 10, 30),
                ItemDropRule.Common(ItemID.TinOre, 1, 10, 30),
                ItemDropRule.Common(ItemID.IronOre, 1, 10, 25),
                ItemDropRule.Common(ItemID.LeadOre, 1, 10, 25),
                ItemDropRule.Common(ItemID.SilverOre, 1, 5, 25),
                ItemDropRule.Common(ItemID.TungstenOre, 1, 5, 25),
                ItemDropRule.Common(ItemID.GoldOre, 1, 5, 20),
                ItemDropRule.Common(ItemID.PlatinumOre, 1, 5, 20),
            ];
            itemLoot.Add(new OneFromRulesRule(1, oreTypes));
            itemLoot.Add(new OneFromRulesRule(1, oreTypes));
            itemLoot.Add(new OneFromRulesRule(1, oreTypes));
        }
    }
}