using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.DataStructures;
using Microsoft.Xna.Framework;
using TanusBetterVanilla.Content.Items.Materials;
using Terraria.GameContent.ItemDropRules;
using TanusBetterVanilla.Content.Tiles.Furniture;
using System;
using System.Collections.Generic;

namespace TanusBetterVanilla.Content.Items.Tiles
{
    public class BorbPlushie : ModItem
    {
        public override void SetDefaults()
        {
            Item.width = 16;
            Item.height = 32;
            Item.maxStack = 99;
            Item.value = 100;
            Item.useTurn = true;
            Item.useTime = 10;
            Item.useAnimation = 15;
            Item.useStyle = ItemUseStyleID.Swing;
            Item.consumable = true;
            Item.rare = ItemRarityID.Expert;
            Item.createTile = ModContent.TileType<BorbPlush>();
        }

        public override void AddRecipes()
        {
            CreateRecipe()
                .AddIngredient(ItemID.Feather, 8)
                .AddIngredient(ItemID.Silk, 10)
                .AddIngredient(ItemID.Daybloom, 4)
                .AddIngredient(ItemID.Owl, 1)
                .AddTile(TileID.Loom)
                .Register();
        }

        public override void ModifyTooltips(List<TooltipLine> tooltips)
        {
            tooltips.Add(new TooltipLine(Mod, "CustomTooltip", "Incredibly Cute\nV=4/3*pi*r³"));
        }
    }
}